import { 
  ServerFilter, 
  Server, 
  ServerWithPlayers, 
  Chat, 
  Message, 
  EmailAccount,
  StaffAccount
} from "@shared/schema";

export async function fetchServers(filters: Partial<ServerFilter>) {
  const searchParams = new URLSearchParams();

  if (filters.search) searchParams.set("search", filters.search);
  if (filters.gameMode) searchParams.set("gameMode", filters.gameMode);
  if (filters.status) searchParams.set("status", filters.status);
  if (filters.page) searchParams.set("page", filters.page.toString());
  if (filters.limit) searchParams.set("limit", filters.limit.toString());

  const response = await fetch(`/api/servers?${searchParams}`);
  if (!response.ok) throw new Error("Failed to fetch servers");
  return response.json();
}

export async function fetchServer(id: number): Promise<ServerWithPlayers> {
  const response = await fetch(`/api/servers/${id}`);
  if (!response.ok) throw new Error("Failed to fetch server details");
  return response.json();
}

export async function fetchChat(): Promise<Chat> {
  const response = await fetch("/api/help/chat");
  if (!response.ok) throw new Error("Failed to fetch chat");
  return response.json();
}

export async function sendMessage(content: string): Promise<Message> {
  const response = await fetch("/api/help/chat/message", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ content })
  });

  if (!response.ok) throw new Error("Failed to send message");
  return response.json();
}

export async function adminLogin(email: string, password: string) {
  const response = await fetch("/api/help/admin/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ email, password })
  });

  if (!response.ok) throw new Error("Invalid credentials");
  return response.json();
}

export async function fetchAdminChats(): Promise<Chat[]> {
  const response = await fetch("/api/help/admin/chats");
  if (!response.ok) throw new Error("Failed to fetch admin chats");
  return response.json();
}

export async function addEmailAccount(email: string, password: string): Promise<EmailAccount> {
  const response = await fetch("/api/email-accounts", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ email, password })
  });

  if (!response.ok) throw new Error("Failed to add email account");
  return response.json();
}

export async function fetchEmailAccounts(): Promise<EmailAccount[]> {
  const response = await fetch("/api/email-accounts");
  if (!response.ok) throw new Error("Failed to fetch email accounts");
  return response.json();
}

export async function deleteEmailAccount(id: number) {
  const response = await fetch(`/api/email-accounts/${id}`, {
    method: "DELETE"
  });

  if (!response.ok) throw new Error("Failed to delete email account");
}

export async function checkFavorite(serverId: number) {
  const response = await fetch(`/api/favorites/check/${serverId}`);
  if (!response.ok) throw new Error("Failed to check favorite status");
  return response.json();
}

export async function addFavorite(serverId: number) {
  const response = await fetch("/api/favorites", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ serverId })
  });

  if (!response.ok) throw new Error("Failed to add favorite");
  return response.json();
}

export async function removeFavorite(serverId: number) {
  const response = await fetch(`/api/favorites/${serverId}`, {
    method: "DELETE"
  });

  if (!response.ok) throw new Error("Failed to remove favorite");
  return true;
}

export async function toggleFavorite(serverId: number) {
  const isFavorite = await checkFavorite(serverId);

  if (isFavorite) {
    const response = await fetch(`/api/favorites/${serverId}`, {
      method: "DELETE"
    });
    if (!response.ok) throw new Error("Failed to remove from favorites");
    return false;
  } else {
    const response = await fetch("/api/favorites", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ serverId })
    });
    if (!response.ok) throw new Error("Failed to add to favorites");
    return true;
  }
}

export async function connectToServer(ip: string, port: number): Promise<{ success: boolean; message: string; error?: string }> {
  const response = await fetch("/api/connect", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ ip, port })
  });

  const data = await response.json();
  if (!response.ok) {
    return {
      success: false,
      message: data.message || "Failed to connect to server",
      error: data.error || "CONNECTION_ERROR"
    };
  }

  return {
    success: true,
    message: data.message || "Connected successfully"
  };
}

// Staff-related functions
export async function staffLogin(email: string, password: string): Promise<StaffAccount> {
  const response = await fetch("/api/staff/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ email, password })
  });

  if (!response.ok) throw new Error("Invalid credentials");
  return response.json();
}

export async function fetchStaffAccounts(): Promise<StaffAccount[]> {
  const response = await fetch("/api/staff/accounts");
  if (!response.ok) throw new Error("Failed to fetch staff accounts");
  return response.json();
}

export async function addStaffMember(email: string, password: string, role: string): Promise<StaffAccount> {
  const response = await fetch("/api/staff/accounts", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ email, password, role })
  });

  if (!response.ok) throw new Error("Failed to add staff member");
  return response.json();
}

export async function deleteStaffMember(id: number) {
  const response = await fetch(`/api/staff/accounts/${id}`, {
    method: "DELETE"
  });

  if (!response.ok) throw new Error("Failed to delete staff member");
}

// Chat support functions
export async function fetchSupportChats(): Promise<Chat[]> {
  const response = await fetch("/api/support/chats");
  if (!response.ok) throw new Error("Failed to fetch support chats");
  return response.json();
}

export async function createSupportChat(): Promise<Chat> {
  const response = await fetch("/api/support/chats", {
    method: "POST"
  });

  if (!response.ok) throw new Error("Failed to create support chat");
  return response.json();
}

export async function sendSupportMessage(chatId: number, content: string): Promise<Message> {
  const response = await fetch(`/api/support/chats/${chatId}/messages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ content })
  });

  if (!response.ok) throw new Error("Failed to send message");
  return response.json();
}

export async function fetchSupportChat(chatId: number): Promise<Chat> {
  const response = await fetch(`/api/support/chats/${chatId}`);
  if (!response.ok) throw new Error("Failed to fetch chat");
  return response.json();
}