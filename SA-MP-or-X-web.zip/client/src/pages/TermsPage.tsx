import React from "react";
import { FileText } from "lucide-react";
import { Footer } from "@/components/Footer";

export default function TermsPage() {
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="container mx-auto px-4 py-8 flex-grow bg-black/40">
        <div className="max-w-4xl mx-auto bg-dark/70 backdrop-blur-lg rounded-lg shadow-lg p-6 md:p-8 border border-primary/20">
          <div className="flex items-center mb-6">
            <FileText className="h-8 w-8 text-primary mr-3" />
            <h1 className="text-3xl font-bold text-foreground">Términos y Condiciones</h1>
          </div>
          
          <div className="prose prose-invert max-w-none">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-primary">📜 TÉRMINOS Y CONDICIONES – SA-MP | X 🚀</h2>
              <p className="mt-4">
                Bienvenido a <strong>SA-MP | X</strong>, el launcher oficial de <strong>Universo X</strong>. 
                Antes de usarlo, es importante que leas y aceptes los siguientes términos:
              </p>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">1. USO DEL SOFTWARE</h3>
              <ul className="space-y-2">
                <li><strong>1️⃣</strong> SA-MP | X es exclusivo para el acceso a Universo X en SAMP.</li>
                <li><strong>2️⃣</strong> Prohibido modificar, descompilar o distribuir sin autorización.</li>
                <li><strong>3️⃣</strong> Su uso es voluntario y no obligatorio para jugar.</li>
                <li><strong>4️⃣</strong> No nos hacemos responsables por daños en archivos del usuario.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">2. ACCESO Y DISPONIBILIDAD</h3>
              <ul className="space-y-2">
                <li><strong>5️⃣</strong> SA-MP | X está en <strong>fase beta</strong>, pueden presentarse errores.</li>
                <li><strong>6️⃣</strong> La disponibilidad puede cambiar sin previo aviso.</li>
                <li><strong>7️⃣</strong> Nos reservamos el derecho de suspender el acceso por mal uso.</li>
                <li><strong>8️⃣</strong> Su uso en otros servidores es bajo tu responsabilidad.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">3. PRIVACIDAD Y SEGURIDAD</h3>
              <ul className="space-y-2">
                <li><strong>9️⃣</strong> No recopilamos ni almacenamos información personal sensible.</li>
                <li><strong>🔟</strong> La seguridad de tu cuenta es tu responsabilidad.</li>
                <li><strong>1️⃣1️⃣</strong> Manipular el launcher con fines malintencionados resultará en <strong>sanción permanente</strong>.</li>
                <li><strong>1️⃣2️⃣</strong> El uso de software no autorizado puede llevar a <strong>bloqueo de cuenta</strong>.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">4. SOPORTE Y RESPONSABILIDAD</h3>
              <ul className="space-y-2">
                <li><strong>1️⃣3️⃣</strong> SA-MP | X se proporciona "tal cual", sin garantías de funcionamiento perfecto.</li>
                <li><strong>1️⃣4️⃣</strong> Para problemas, contacta al <strong>soporte en Discord</strong>.</li>
                <li><strong>1️⃣5️⃣</strong> No nos hacemos responsables por errores de compatibilidad.</li>
                <li><strong>1️⃣6️⃣</strong> La instalación es bajo tu propio riesgo.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">5. ACTUALIZACIONES Y MODIFICACIONES</h3>
              <ul className="space-y-2">
                <li><strong>1️⃣7️⃣</strong> Nos reservamos el derecho de actualizar o suspender SA-MP | X en cualquier momento.</li>
                <li><strong>1️⃣8️⃣</strong> Algunas actualizaciones pueden ser obligatorias.</li>
                <li><strong>1️⃣9️⃣</strong> No nos hacemos responsables por pérdida de datos tras una actualización.</li>
                <li><strong>2️⃣0️⃣</strong> Estos términos pueden cambiar en cualquier momento, revisarlos es tu responsabilidad.</li>
              </ul>
            </div>
            
            <div className="mt-8 p-4 bg-primary/10 border border-primary/20 rounded-lg">
              <p className="font-semibold text-center">
                📌 <strong>Al descargar y usar SA-MP | X, aceptas automáticamente estos términos y condiciones. 
                Si no estás de acuerdo, no uses el software.</strong>
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}