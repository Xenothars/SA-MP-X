import React from "react";
import { Rocket } from "lucide-react";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function LaunchersPage() {
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="container mx-auto px-4 py-8 flex-grow bg-black/40">
        <div className="max-w-4xl mx-auto bg-dark/70 backdrop-blur-lg rounded-lg shadow-lg p-6 md:p-8 border border-primary/20">
          <div className="flex items-center mb-6">
            <Rocket className="h-8 w-8 text-primary mr-3" />
            <h1 className="text-3xl font-bold text-foreground">Nuestros Launchers</h1>
          </div>
          
          <div className="prose prose-invert max-w-none">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-primary">🚀 Colección de Launchers Personalizados 🚀</h2>
              <p className="mt-4">
                Explora los diferentes launchers que hemos creado para servidores de SA-MP.
              </p>
            </div>
            
            {/* Lista de launchers (Contenido que se agregará en el futuro) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
              <div className="bg-dark/50 rounded-lg border border-primary/20 p-4 hover:border-primary/50 transition-colors">
                <div className="text-xl font-bold text-primary mb-2">SA-MP | X</div>
                <p className="text-light/80 mb-4">Nuestro launcher principal con todas las características premium incluidas.</p>
              </div>
              
              <div className="bg-dark/50 rounded-lg border border-primary/20 p-4 hover:border-primary/50 transition-colors">
                <div className="text-xl font-bold text-primary mb-2">Próximamente</div>
                <p className="text-light/80 mb-4">Estamos trabajando en nuevos launchers personalizados. ¡Mantente atento!</p>
              </div>
            </div>
            
            <div className="mt-10 p-5 bg-primary/10 rounded-lg border border-primary/20">
              <h3 className="text-xl font-bold text-primary mb-3">¿Quieres tu propio launcher personalizado?</h3>
              <p>
                Podemos crear un launcher exclusivo para tu servidor con tu propio diseño y funcionalidades personalizadas.
              </p>
              <div className="mt-4 flex justify-center">
                <Link href="/customize">
                  <Button className="bg-primary hover:bg-primary/90">
                    Ver opciones de personalización
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}