import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { FaDiscord, FaDownload, FaListAlt, FaShare, FaUserShield, FaGlobe, FaRocket } from "react-icons/fa";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="flex-grow flex flex-col items-center justify-center px-4 bg-black/40 relative">
        {/* Marca de agua */}
        <div className="absolute bottom-4 right-4 text-xs text-white/40 font-light select-none pointer-events-none">
          Crédito: Alyn SA-MP Mobile
        </div>
        <div className="text-center max-w-3xl w-full p-8 rounded-2xl backdrop-blur-lg bg-dark/70 border border-primary/20 shadow-2xl">
          {/* Logo */}
          <div className="w-48 h-48 mx-auto mb-4">
            <img 
              src="/images/samp-x-logo.png" 
              alt="SA-MP X Logo" 
              className="w-full h-full object-contain drop-shadow-[0_0_10px_rgba(131,56,236,0.7)] rounded-full"
            />
          </div>
          
          {/* Launcher Name */}
          <h1 className="text-5xl md:text-6xl font-extrabold mb-6 bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
            SA-MP | X
          </h1>
          
          <p className="text-xl text-light/90 mb-10">
            Tu portal a los mejores servidores de San Andreas Multiplayer
          </p>
          
          {/* Navigation Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md mx-auto">
            {/* Discord Button */}
            <a 
              href="https://discord.gg/qnN7GqeCnf" 
              target="_blank" 
              rel="noopener noreferrer"
              className="block w-full"
            >
              <Button 
                size="lg"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center gap-2 py-6 text-lg shadow-lg"
              >
                <FaDiscord className="w-5 h-5" />
                Discord
              </Button>
            </a>
            
            {/* Social Media Button */}
            <Button 
              size="lg"
              className="w-full bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600 text-white flex items-center justify-center gap-2 py-6 text-lg shadow-lg"
            >
              <FaShare className="w-5 h-5" />
              Redes Sociales
            </Button>
            
            {/* Official Website Button */}
            <a 
              href="https://universox.net" 
              target="_blank" 
              rel="noopener noreferrer"
              className="block w-full"
            >
              <Button 
                size="lg"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center gap-2 py-6 text-lg shadow-lg"
              >
                <FaGlobe className="w-5 h-5" />
                Universo X
              </Button>
            </a>
            
            {/* Servers Button */}
            <Link href="/servers">
              <Button 
                size="lg"
                className="w-full bg-primary hover:bg-primary/90 text-white flex items-center justify-center gap-2 py-6 text-lg shadow-lg"
              >
                <FaListAlt className="w-5 h-5" />
                Lista de Servidores
              </Button>
            </Link>
            
            {/* Launchers Button */}
            <Link href="/launchers">
              <Button 
                size="lg"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white flex items-center justify-center gap-2 py-6 text-lg shadow-lg"
              >
                <FaRocket className="w-5 h-5" />
                Nuestros Launchers
              </Button>
            </Link>
            
            {/* Download Button */}
            <Button 
              size="lg"
              className="w-full bg-green-600 hover:bg-green-700 text-white flex items-center justify-center gap-2 py-6 text-lg shadow-lg"
            >
              <FaDownload className="w-5 h-5" />
              Descargar Launcher
            </Button>
          </div>
          
          {/* Staff Button - Positioned separately */}
          <div className="mt-8">
            <Link href="/admin/login">
              <Button 
                variant="outline"
                className="text-primary hover:bg-primary/10 border-primary/30 flex items-center justify-center gap-2"
              >
                <FaUserShield className="w-4 h-4" />
                Acceso para Staff
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
