
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Mail, MessageCircle, Globe } from "lucide-react";

export default function ContactPage() {
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="flex-grow flex flex-col bg-black/40">
        <Header />
        
        <main className="container mx-auto px-4 py-8 flex-grow">
          <div className="max-w-2xl mx-auto">
            <h1 className="text-4xl font-bold text-center mb-8 bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              Contacta con Nosotros
            </h1>
            
            <div className="grid gap-6">
              {/* Email */}
              <a href="mailto:universo.x.samp@gmail.com" className="block">
                <div className="glass-card p-6 hover:bg-primary/5 transition-colors">
                  <div className="flex items-center gap-4">
                    <Mail className="h-8 w-8 text-primary" />
                    <div>
                      <h2 className="text-xl font-semibold mb-2">Correo Electrónico</h2>
                      <p className="text-light/70">universo.x.samp@gmail.com</p>
                    </div>
                  </div>
                </div>
              </a>

              {/* Discord */}
              <a href="https://discord.gg/qnN7GqeCnf" target="_blank" rel="noopener noreferrer" className="block">
                <div className="glass-card p-6 hover:bg-primary/5 transition-colors">
                  <div className="flex items-center gap-4">
                    <MessageCircle className="h-8 w-8 text-primary" />
                    <div>
                      <h2 className="text-xl font-semibold mb-2">Discord</h2>
                      <p className="text-light/70">Únete a nuestra comunidad en Discord</p>
                    </div>
                  </div>
                </div>
              </a>

              {/* Website */}
              <div className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <Globe className="h-8 w-8 text-primary" />
                  <div>
                    <h2 className="text-xl font-semibold mb-2">Sitio Web</h2>
                    <p className="text-light/70">SA-MP | X</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}
