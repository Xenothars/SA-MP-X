
import React from 'react';
import { useLocation } from 'wouter';
import { useMutation } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { LogIn, Shield } from 'lucide-react';

export default function StaffLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');

  // Verificar si ya hay una sesión activa
  React.useEffect(() => {
    const staffId = localStorage.getItem('staffId');
    const staffRole = localStorage.getItem('staffRole');
    
    if (staffId && staffRole) {
      // Redirigir según el rol
      if (staffRole === 'owner') {
        setLocation('/admin/panel');
      } else {
        setLocation('/admin/chat');
      }
    }
  }, [setLocation]);

  const { mutate: login, isPending } = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/staff/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      if (!response.ok) throw new Error('Invalid credentials');
      return response.json();
    },
    onSuccess: (data) => {
      // Guardar información de la sesión
      localStorage.setItem('staffId', data.staff.id);
      localStorage.setItem('staffRole', data.staff.role);
      localStorage.setItem('staffEmail', data.staff.email);
      
      toast({ 
        description: "Inicio de sesión exitoso",
        variant: "default" 
      });
      
      // Redirigir según el rol
      if (data.staff.role === 'owner') {
        setLocation('/admin/panel');
      } else {
        setLocation('/admin/chat');
      }
    },
    onError: () => {
      toast({
        variant: "destructive",
        description: "Credenciales inválidas"
      });
    }
  });

  return (
    <div 
      className="min-h-screen flex items-center justify-center bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="w-full max-w-md p-8 bg-black/40 backdrop-blur-sm rounded-lg shadow-lg">
        <div className="flex flex-col items-center mb-6">
          <Shield className="h-12 w-12 text-primary mb-2" />
          <h1 className="text-2xl font-bold text-center">Acceso de Personal</h1>
          <p className="text-center text-light/70">Inicia sesión para acceder al panel de administración</p>
        </div>
        
        <form onSubmit={(e) => {
          e.preventDefault();
          login();
        }} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="email" className="text-sm font-medium">
              Correo Electrónico
            </label>
            <Input
              id="email"
              type="email"
              placeholder="tu@correo.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-dark/50 border-light/20"
              required
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="password" className="text-sm font-medium">
              Contraseña
            </label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-dark/50 border-light/20"
              required
            />
          </div>
          
          <Button
            type="submit"
            className="w-full mt-4"
            disabled={isPending}
          >
            {isPending ? (
              <span className="flex items-center gap-2">
                <span className="animate-spin">⌛</span> Verificando...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <LogIn className="h-4 w-4" /> Iniciar sesión
              </span>
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
