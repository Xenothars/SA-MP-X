import React from "react";
import { ShieldAlert } from "lucide-react";
import { Footer } from "@/components/Footer";

export default function PrivacyPage() {
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="container mx-auto px-4 py-8 flex-grow bg-black/40">
        <div className="max-w-4xl mx-auto bg-dark/70 backdrop-blur-lg rounded-lg shadow-lg p-6 md:p-8 border border-primary/20">
          <div className="flex items-center mb-6">
            <ShieldAlert className="h-8 w-8 text-primary mr-3" />
            <h1 className="text-3xl font-bold text-foreground">Política de Privacidad</h1>
          </div>
          
          <div className="prose prose-invert max-w-none">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-primary">🔒 POLÍTICA DE PRIVACIDAD – SA-MP | X 🚀</h2>
              <p className="mt-4">
                En <strong>Universo X</strong>, nos tomamos la privacidad de nuestros usuarios en serio. 
                A continuación, te explicamos cómo maneja la información nuestro launcher <strong>SA-MP | X</strong>.
              </p>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">📌 1. RECOLECCIÓN DE DATOS</h3>
              <ul className="space-y-2">
                <li>🔹 <strong>SA-MP | X no recopila, almacena ni comparte información personal</strong> de los usuarios.</li>
                <li>🔹 No accedemos a archivos fuera de los necesarios para el funcionamiento del launcher.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">📌 2. USO DEL SOFTWARE</h3>
              <ul className="space-y-2">
                <li>🔹 El launcher solo ejecuta archivos relacionados con <strong>Universo X</strong> y <strong>SAMP</strong>.</li>
                <li>🔹 No incluye ningún tipo de spyware, adware o software malicioso.</li>
                <li>🔹 No recopilamos credenciales de inicio de sesión ni datos de tus cuentas.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">📌 3. SEGURIDAD</h3>
              <ul className="space-y-2">
                <li>🔹 <strong>SA-MP | X no interfiere con tu sistema ni realiza modificaciones sin tu consentimiento.</strong></li>
                <li>🔹 Recomendamos <strong>descargar siempre el launcher desde fuentes oficiales</strong> para evitar versiones alteradas por terceros.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">📌 4. CONEXIÓN A SERVIDORES</h3>
              <ul className="space-y-2">
                <li>🔹 El launcher se conecta únicamente a los servidores de <strong>Universo X</strong> para facilitar el acceso al juego.</li>
                <li>🔹 No transmitimos datos personales ni información sensible a servidores externos.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">📌 5. ACTUALIZACIONES Y MODIFICACIONES</h3>
              <ul className="space-y-2">
                <li>🔹 Podemos actualizar o modificar el launcher para mejorar la experiencia del usuario.</li>
                <li>🔹 No obligamos a los usuarios a instalar actualizaciones, pero algunas pueden ser necesarias para el correcto funcionamiento.</li>
              </ul>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">📌 6. CAMBIOS EN LA POLÍTICA DE PRIVACIDAD</h3>
              <ul className="space-y-2">
                <li>🔹 Nos reservamos el derecho de modificar esta política en cualquier momento.</li>
                <li>🔹 Es responsabilidad del usuario revisar periódicamente los cambios.</li>
              </ul>
            </div>
            
            <div className="mt-8 p-4 bg-primary/10 border border-primary/20 rounded-lg">
              <p className="font-semibold text-center">
                📌 <strong>Al utilizar SA-MP | X, aceptas esta política de privacidad. Si tienes dudas o inquietudes, 
                puedes contactarnos a través de nuestro Discord oficial.</strong>
              </p>
            </div>
            
            <div className="mt-8 text-center">
              <p className="font-semibold">
                📢 <strong>Gracias por confiar en Universo X. ¡Nos vemos en el juego!</strong> 🚀🌌
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}