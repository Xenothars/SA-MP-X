import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { fetchServer, checkFavorite, addFavorite, removeFavorite } from "@/lib/api";
import { ServerWithPlayers } from "@shared/schema";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ConnectionModal } from "@/components/ConnectionModal";
import { ErrorModal } from "@/components/ErrorModal";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { 
  Hash, 
  Users, 
  Globe, 
  Activity, 
  Star, 
  ArrowLeft, 
  LogIn,
  Gamepad as GamepadIcon,
  Info as InfoIcon
} from "lucide-react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";

export default function ServerDetails() {
  const { toast } = useToast();
  const [, params] = useRoute<{ id: string }>("/servers/:id");
  const serverId = params ? parseInt(params.id) : 0;
  const [isFavorite, setIsFavorite] = React.useState(false);
  const [connectionOpen, setConnectionOpen] = React.useState(false);
  const [errorOpen, setErrorOpen] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState("");
  const [errorCode, setErrorCode] = React.useState("");

  // Fetch server details
  const { 
    data: server, 
    isLoading, 
    isError,
    refetch 
  } = useQuery({
    queryKey: [`/api/servers/${serverId}`],
    queryFn: () => fetchServer(serverId),
    enabled: serverId > 0
  });

  // Check if server is in favorites
  const { data: favoriteStatus } = useQuery({
    queryKey: [`/api/favorites/check/${serverId}`],
    queryFn: () => checkFavorite(serverId),
    enabled: serverId > 0,
    onSuccess: (data) => {
      setIsFavorite(data);
    }
  });

  // Connect to server mutation
  const { mutate: connectMutation, isPending: isConnecting } = useMutation({
    mutationFn: ({ ip, port }: { ip: string, port: number }) => connectToServer(ip, port),
    onSuccess: (data) => {
      setConnectionOpen(false);
      
      if (!data.success) {
        setErrorMessage(data.message);
        setErrorCode(data.error || "UNKNOWN_ERROR");
        setErrorOpen(true);
        return;
      }
      
      toast({
        title: "Conexión iniciada",
        description: "Conectando al servidor...",
      });
    },
    onError: (error) => {
      setConnectionOpen(false);
      setErrorMessage("No se pudo conectar al servidor");
      setErrorCode("CONNECTION_FAILED");
      setErrorOpen(true);
    }
  });

  // Toggle favorite mutation
  const { mutate: toggleFavoriteMutation } = useMutation({
    mutationFn: async (serverId: number) => {
      if (isFavorite) {
        await removeFavorite(serverId);
        return false;
      } else {
        await addFavorite(serverId);
        return true;
      }
    },
    onSuccess: (newStatus) => {
      setIsFavorite(newStatus);
      toast({
        description: newStatus 
          ? "Servidor añadido a favoritos" 
          : "Servidor eliminado de favoritos",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/favorites'] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo actualizar favoritos. Inténtalo de nuevo.",
      });
    }
  });

  // Calculate player percentage
  const playerPercentage = server?.maxPlayers
    ? Math.floor((server.currentPlayers / server.maxPlayers) * 100)
    : 0;

  // Handle connect button click
  const handleConnect = () => {
    if (!server) return;
    setConnectionOpen(true);
  };

  // Initiate connection
  const handleInitiateConnection = () => {
    if (!server) return;
    
    connectMutation({
      ip: server.ip,
      port: server.port
    });
  };

  // Toggle favorite status
  const handleToggleFavorite = () => {
    if (!server) return;
    toggleFavoriteMutation(server.id);
  };

  return (
    <div className="min-h-screen flex flex-col bg-dark text-light">
      <Header onRefresh={() => refetch()} isRefreshing={isLoading} />
      
      <main className="container mx-auto px-4 py-6 flex-grow">
        {isError ? (
          <div className="text-center py-8">
            <h2 className="text-xl font-semibold text-red-400 mb-2">
              Error al cargar la información del servidor
            </h2>
            <p className="text-light/70 mb-4">
              No se ha podido obtener la información del servidor. Por favor, inténtalo de nuevo.
            </p>
            <Button 
              onClick={() => refetch()} 
              variant="primary"
              className="mr-2"
            >
              Reintentar
            </Button>
            <Button 
              variant="outline"
              onClick={() => window.history.back()}
            >
              Volver
            </Button>
          </div>
        ) : isLoading ? (
          <div className="flex flex-col space-y-4">
            <div className="h-12 w-1/3 bg-medium rounded animate-pulse"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="h-80 bg-medium rounded animate-pulse"></div>
              <div className="md:col-span-2 h-80 bg-medium rounded animate-pulse"></div>
            </div>
          </div>
        ) : server ? (
          <>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => window.history.back()}
                  className="mr-2"
                >
                  <ArrowLeft className="h-5 w-5" />
                </Button>
                <h1 className="text-2xl font-bold">{server.name}</h1>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={server.isOnline ? "online" : "offline"}>
                  <span className="w-2 h-2 bg-online rounded-full mr-1"></span>
                  {server.isOnline ? "Online" : "Offline"}
                </Badge>
                <Button 
                  variant="primary" 
                  size="iconSm" 
                  title={isFavorite ? "Quitar de favoritos" : "Añadir a favoritos"}
                  onClick={handleToggleFavorite}
                >
                  <Star className="h-4 w-4" fill={isFavorite ? "currentColor" : "none"} />
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              {/* Server Info Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Información del servidor</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-light/70 flex items-center">
                        <Hash className="h-4 w-4 mr-1" />
                        Dirección:
                      </span>
                      <span className="font-medium">{server.ip}:{server.port}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-light/70 flex items-center">
                        <Users className="h-4 w-4 mr-1" />
                        Jugadores:
                      </span>
                      <span className="font-medium">{server.currentPlayers}/{server.maxPlayers}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-light/70 flex items-center">
                        <Activity className="h-4 w-4 mr-1" />
                        Ping:
                      </span>
                      <span className={server.ping && server.ping < 50 ? "text-green-400" : server.ping && server.ping < 100 ? "text-yellow-400" : "text-red-400"}>
                        {server.ping ? `${server.ping}ms` : "--"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-light/70 flex items-center">
                        <GamepadIcon className="h-4 w-4 mr-1" />
                        Modo:
                      </span>
                      <span className="font-medium">{server.gameMode || "--"}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-light/70 flex items-center">
                        <Globe className="h-4 w-4 mr-1" />
                        Idioma:
                      </span>
                      <span className="font-medium">{server.language || "--"}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-light/70 flex items-center">
                        <InfoIcon className="h-4 w-4 mr-1" />
                        Versión:
                      </span>
                      <span className="font-medium">{server.version || "--"}</span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-light/70">Capacidad:</span>
                      <span className="text-sm">{playerPercentage}%</span>
                    </div>
                    <Progress value={playerPercentage} className="mb-4" />
                  </div>
                  
                  <Button
                    variant="accent" 
                    className="w-full flex items-center justify-center"
                    onClick={handleConnect}
                    disabled={!server.isOnline}
                  >
                    <LogIn className="mr-1 h-4 w-4" />
                    Conectar ahora
                  </Button>
                </CardContent>
              </Card>
              
              {/* Description and Rules */}
              <div className="md:col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Descripción</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {server.description ? (
                      server.description.split('\n\n').map((paragraph, index) => (
                        <p key={index} className={index > 0 ? "mt-2" : ""}>
                          {paragraph}
                        </p>
                      ))
                    ) : (
                      <p className="text-light/70">No hay descripción disponible.</p>
                    )}
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Reglas del servidor</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {server.rules ? (
                      <ul className="list-disc pl-4 space-y-1">
                        {server.rules.split('\n').map((rule, index) => (
                          <li key={index}>{rule}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-light/70">No hay reglas disponibles.</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
            
            {/* Players Table */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  Jugadores conectados ({server.currentPlayers}/{server.maxPlayers})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {server.players && server.players.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nombre</TableHead>
                        <TableHead>Nivel</TableHead>
                        <TableHead>Ping</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {server.players.map((player, index) => (
                        <TableRow key={player.id}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell>{player.name}</TableCell>
                          <TableCell>{player.level || "--"}</TableCell>
                          <TableCell>{player.ping ? `${player.ping}ms` : "--"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center text-light/50 py-4">
                    No hay jugadores conectados
                  </div>
                )}
                
                {server.players && server.players.length > 0 && server.players.length < server.currentPlayers && (
                  <div className="mt-2 text-center text-xs text-light/50">
                    Mostrando {server.players.length} de {server.currentPlayers} jugadores
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        ) : null}
      </main>
      
      <Footer />
      
      {/* Modals */}
      <ConnectionModal
        server={server || null}
        open={connectionOpen}
        onOpenChange={setConnectionOpen}
        onConnect={handleInitiateConnection}
        isConnecting={isConnecting}
      />
      
      <ErrorModal
        open={errorOpen}
        onOpenChange={setErrorOpen}
        errorMessage={errorMessage}
        errorCode={errorCode}
      />
    </div>
  );
}
