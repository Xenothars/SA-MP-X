
import React from "react";
import { useParams, useLocation } from "wouter";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MessageCircle, Users, LogOut, ArrowLeft, RefreshCw, ShieldCheck } from "lucide-react";

interface Message {
  id: number;
  content: string;
  sender: string;
  createdAt: string;
}

interface Chat {
  id: number;
  userId: string;
  lastMessage: string;
  status: string;
  timestamp: string;
  hasNewMessages?: boolean; // Indica si hay nuevos mensajes no leídos
  messageCount?: number;
}

export default function AdminChat() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const chatId = params.chatId ? parseInt(params.chatId) : null;
  const [selectedChat, setSelectedChat] = React.useState<number | null>(chatId);
  const [message, setMessage] = React.useState("");
  const [role, setRole] = React.useState<string | null>(null);
  const messagesEndRef = React.useRef<HTMLDivElement>(null);
  
  // Verificar autenticación
  React.useEffect(() => {
    const staffId = localStorage.getItem('staffId');
    const staffRole = localStorage.getItem('staffRole');
    
    if (!staffId || !staffRole) {
      setLocation('/admin/login');
    } else {
      setRole(staffRole);
    }
  }, [setLocation]);
  
  // Cuando se selecciona un chat, actualizar la URL y marcar mensajes como leídos
  React.useEffect(() => {
    if (selectedChat) {
      setLocation(`/admin/chat/${selectedChat}`);
      
      // Marcar mensajes como leídos cuando se selecciona un chat
      const markAsRead = async () => {
        try {
          const staffId = localStorage.getItem('staffId');
          const response = await fetch(`/api/help/admin/chat/${selectedChat}/read`, {
            method: 'PATCH',
            headers: { 
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${staffId}`
            }
          });
          
          if (response.ok) {
            // Actualizar la caché para reflejar que los mensajes fueron leídos
            queryClient.invalidateQueries({ queryKey: ['/api/help/admin/chats'] });
          }
        } catch (error) {
          console.error("Error al marcar mensajes como leídos:", error);
        }
      };
      
      markAsRead();
    }
  }, [selectedChat, setLocation, queryClient]);
  
  // Obtener la lista de chats
  const { 
    data: chats,
    isLoading: isLoadingChats,
    refetch: refetchChats 
  } = useQuery({
    queryKey: ['/api/help/admin/chats'],
    queryFn: async () => {
      const staffId = localStorage.getItem('staffId');
      
      const response = await fetch('/api/help/admin/chats', {
        headers: {
          'Authorization': `Bearer ${staffId}`
        }
      });
      
      if (!response.ok) throw new Error('Error al obtener los chats');
      return response.json();
    },
    enabled: !!role
  });
  
  // Obtener mensajes de un chat específico
  const { 
    data: chatDetails,
    isLoading: isLoadingChat,
    refetch: refetchMessages
  } = useQuery({
    queryKey: ['/api/help/admin/chat', selectedChat],
    queryFn: async () => {
      if (!selectedChat) return null;
      
      const staffId = localStorage.getItem('staffId');
      
      const response = await fetch(`/api/help/admin/chat/${selectedChat}`, {
        headers: {
          'Authorization': `Bearer ${staffId}`
        }
      });
      
      if (!response.ok) throw new Error('Error al obtener los mensajes');
      return response.json();
    },
    enabled: !!selectedChat && !!role
  });
  
  // Enviar mensaje
  const { mutate: sendMessage, isPending: isSending } = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedChat) return null;
      
      const staffId = localStorage.getItem('staffId');
      
      const response = await fetch('/api/help/admin/message', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${staffId}`
        },
        body: JSON.stringify({ 
          content, 
          channelId: selectedChat,
          staffId
        })
      });
      
      if (!response.ok) throw new Error('Error al enviar el mensaje');
      return response.json();
    },
    onSuccess: () => {
      setMessage("");
      refetchMessages();
      toast({ description: "Mensaje enviado correctamente" });
    },
    onError: () => {
      toast({
        variant: "destructive",
        description: "Error al enviar el mensaje"
      });
    }
  });
  
  // Actualizar estado del chat
  const { mutate: updateChatStatus } = useMutation({
    mutationFn: async ({ chatId, status }: { chatId: number, status: string }) => {
      const staffId = localStorage.getItem('staffId');
      
      const response = await fetch(`/api/help/admin/chat/${chatId}/status`, {
        method: 'PATCH',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${staffId}`
        },
        body: JSON.stringify({ status })
      });
      
      if (!response.ok) throw new Error('Error al actualizar el estado del chat');
      return response.json();
    },
    onSuccess: () => {
      refetchChats();
      refetchMessages();
      toast({ description: "Estado del chat actualizado" });
    },
    onError: () => {
      toast({
        variant: "destructive",
        description: "Error al actualizar el estado del chat"
      });
    }
  });
  
  // Scroll hacia el último mensaje
  React.useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatDetails]);
  
  const handleSendMessage = () => {
    if (message.trim()) {
      sendMessage(message);
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  const handleLogout = () => {
    localStorage.removeItem('staffId');
    localStorage.removeItem('staffRole');
    localStorage.removeItem('staffEmail');
    setLocation('/admin/login');
  };
  
  if (!role) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-dark">
        <Card className="p-6 text-center">
          <h1 className="text-xl">Verificando acceso...</h1>
        </Card>
      </div>
    );
  }
  
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="flex-grow flex flex-col bg-black/40">
        <Header onRefresh={() => {
          refetchChats();
          if (selectedChat) refetchMessages();
        }} />
        
        <main className="container mx-auto px-4 py-8 flex-grow">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-2">
              {role === 'owner' ? (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setLocation('/admin/panel')}
                >
                  <ArrowLeft className="h-4 w-4 mr-2" /> 
                  Panel de Admin
                </Button>
              ) : (
                <h1 className="text-xl font-bold flex items-center">
                  <MessageCircle className="h-5 w-5 text-primary mr-2" />
                  Panel de Soporte
                </h1>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  refetchChats();
                  if (selectedChat) refetchMessages();
                }}
                disabled={isLoadingChats || isLoadingChat}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoadingChats || isLoadingChat ? 'animate-spin' : ''}`} />
                Actualizar
              </Button>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Cerrar Sesión
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-12 gap-6">
            {/* Lista de chats */}
            <div className="col-span-12 md:col-span-4 glass-card p-4">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Chats de Soporte
              </h2>
              
              {isLoadingChats ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : chats && chats.length > 0 ? (
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {chats.map((chat: Chat) => (
                    <div
                      key={chat.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedChat === chat.id 
                          ? 'bg-primary/20' 
                          : 'bg-dark/50 hover:bg-dark/70'
                      }`}
                      onClick={() => setSelectedChat(chat.id)}
                    >
                      <div className="flex justify-between items-center">
                        <div className="font-medium flex items-center gap-2">
                          Usuario #{chat.userId}
                          {chat.hasNewMessages && (
                            <span className="relative flex h-3 w-3">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                            </span>
                          )}
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          chat.status === 'open' 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {chat.status === 'open' ? 'Abierto' : 'En espera'}
                        </span>
                      </div>
                      <div className="text-sm text-light/70 truncate mt-1 flex justify-between">
                        <span>{chat.lastMessage}</span>
                        {chat.messageCount && chat.messageCount > 0 && (
                          <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-primary text-xs font-semibold text-white">
                            {chat.messageCount}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-light/50 mt-1">
                        {new Date(chat.timestamp).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-light/50">
                  No hay chats activos en este momento
                </div>
              )}
            </div>
            
            {/* Área de chat */}
            <div className="col-span-12 md:col-span-8 glass-card p-4">
              {selectedChat ? (
                <>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium flex items-center">
                      <ShieldCheck className="h-4 w-4 mr-2 text-primary" />
                      {chatDetails ? `Conversación con Usuario #${chatDetails.userId}` : 'Cargando...'}
                    </h3>
                    
                    {chatDetails && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant={chatDetails.status === 'open' ? 'outline' : 'default'}
                          onClick={() => updateChatStatus({ 
                            chatId: selectedChat, 
                            status: 'open' 
                          })}
                          disabled={chatDetails.status === 'open'}
                        >
                          Abrir
                        </Button>
                        <Button
                          size="sm"
                          variant={chatDetails.status === 'waiting' ? 'outline' : 'default'}
                          onClick={() => updateChatStatus({ 
                            chatId: selectedChat, 
                            status: 'waiting' 
                          })}
                          disabled={chatDetails.status === 'waiting'}
                        >
                          Espera
                        </Button>
                        <Button
                          size="sm"
                          variant={chatDetails.status === 'closed' ? 'outline' : 'default'}
                          onClick={() => updateChatStatus({ 
                            chatId: selectedChat, 
                            status: 'closed' 
                          })}
                          disabled={chatDetails.status === 'closed'}
                        >
                          Cerrar
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  <div className="h-[500px] bg-dark/50 rounded-lg p-4 mb-4 overflow-y-auto">
                    {isLoadingChat ? (
                      <div className="flex justify-center items-center h-full">
                        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                      </div>
                    ) : chatDetails?.messages?.length > 0 ? (
                      <div className="space-y-4">
                        {chatDetails.messages.map((msg: Message) => (
                          <div 
                            key={msg.id}
                            className={`flex ${msg.sender === 'staff' ? 'justify-end' : 'justify-start'}`}
                          >
                            <div 
                              className={`max-w-[80%] rounded-lg p-3 ${
                                msg.sender === 'staff' 
                                  ? 'bg-primary/20 text-white' 
                                  : 'bg-dark/70 text-light'
                              }`}
                            >
                              <div className="text-xs font-semibold mb-1">
                                {msg.sender === 'staff' ? 'Staff' : 'Usuario'}
                              </div>
                              <div className="whitespace-pre-wrap">{msg.content}</div>
                              <div className="text-xs text-light/50 mt-1 text-right">
                                {new Date(msg.createdAt).toLocaleTimeString()}
                              </div>
                            </div>
                          </div>
                        ))}
                        <div ref={messagesEndRef} />
                      </div>
                    ) : (
                      <div className="flex justify-center items-center h-full text-light/50">
                        No hay mensajes en esta conversación
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Escribe tu respuesta..."
                      className="bg-dark/50 min-h-[100px]"
                      disabled={isSending || (chatDetails?.status === 'closed')}
                    />
                    <Button 
                      className="self-end"
                      onClick={handleSendMessage}
                      disabled={isSending || !message.trim() || (chatDetails?.status === 'closed')}
                    >
                      {isSending ? (
                        <span className="flex items-center gap-2">
                          <span className="animate-spin">⌛</span> Enviando...
                        </span>
                      ) : (
                        "Enviar"
                      )}
                    </Button>
                  </div>
                  
                  {chatDetails?.status === 'closed' && (
                    <div className="mt-4 text-center text-yellow-400 bg-yellow-400/10 py-2 rounded-md">
                      Este chat está cerrado. No se pueden enviar más mensajes.
                    </div>
                  )}
                </>
              ) : (
                <div className="h-[600px] flex flex-col items-center justify-center text-light/50">
                  <MessageCircle className="h-16 w-16 text-light/20 mb-4" />
                  <p className="text-xl font-medium mb-2">Chat de Soporte</p>
                  <p>Selecciona una conversación para ver los mensajes</p>
                </div>
              )}
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    </div>
  );
}
