import React from "react";
import { Github, Gift, DollarSign, Rocket } from "lucide-react";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function CustomizePage() {
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="container mx-auto px-4 py-8 flex-grow bg-black/40">
        <div className="max-w-4xl mx-auto bg-dark/70 backdrop-blur-lg rounded-lg shadow-lg p-6 md:p-8 border border-primary/20">
          <div className="flex items-center mb-6">
            <Rocket className="h-8 w-8 text-primary mr-3" />
            <h1 className="text-3xl font-bold text-foreground">Personaliza Tu Launcher</h1>
          </div>
          
          <div className="prose prose-invert max-w-none">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-primary">🚀 PERSONALIZA TU EXPERIENCIA EN SAMP CON SA-MP | X 🚀</h2>
            </div>
            
            <div className="mb-8">
              <p className="text-lg">
                ¡Tenemos una gran propuesta para la comunidad! Si nuestro <strong>Discord</strong> alcanza los <strong>500 usuarios</strong>, 
                sortearemos <strong>6 launchers de SAMP personalizados</strong> para servidores. 🎉
              </p>
            </div>
            
            <div className="mb-8 bg-gradient-to-r from-primary/10 to-purple-500/10 p-5 rounded-lg border border-primary/20">
              <p className="text-lg mb-4">
                Pero si quieres asegurarte de tener tu propio <strong>launcher exclusivo</strong>, 
                te ofrecemos <strong>precios accesibles y competitivos</strong>:
              </p>
              
              <div className="flex items-center my-6">
                <DollarSign className="h-10 w-10 text-green-500 mr-4" />
                <div>
                  <p className="text-xl font-bold">
                    💰 Nuestros precios van desde <span className="text-green-400">$80 a $90</span>
                  </p>
                  <p className="text-lg opacity-80">
                    Mientras que otras empresas cobran entre <span className="line-through">$150, $200 e incluso hasta $500</span>
                  </p>
                  <p className="mt-2">
                    Con <strong className="text-primary">SA-MP | X</strong>, obtienes calidad y personalización a un costo justo.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <p className="text-lg">
                📩 Si te interesa adquirir un launcher o necesitas más información, <strong>contáctanos</strong>. 
                Llévate un <strong>launcher único para tu servidor</strong> y haz que tu comunidad tenga una experiencia profesional.
              </p>
            </div>
            
            <div className="flex justify-center mb-8 gap-4">
              <a href="https://discord.gg/qnN7GqeCnf" target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="flex items-center gap-2 bg-indigo-600/20 border-indigo-400/30 hover:bg-indigo-600/30 text-white">
                  <Gift className="h-5 w-5" />
                  Unirse al Discord
                </Button>
              </a>
              
              <Link href="/contact">
                <Button className="flex items-center gap-2 bg-primary hover:bg-primary/90">
                  <Rocket className="h-5 w-5" />
                  Contactarnos
                </Button>
              </Link>
            </div>
            
            <div className="mt-10 text-center">
              <p className="text-xl font-bold text-primary">
                ✨ ¡Lleva SAMP al siguiente nivel con SA-MP | X! ✨
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}