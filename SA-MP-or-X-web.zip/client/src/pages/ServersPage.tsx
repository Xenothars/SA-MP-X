import React from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { fetchServers, connectToServer } from "@/lib/api";
import { ServerFilter as FilterType, Server } from "@shared/schema";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ServerFilter } from "@/components/ServerFilter";
import { ServerCard } from "@/components/ServerCard";
import { Pagination } from "@/components/Pagination";
import { ServerDetailsModal } from "@/components/ServerDetailsModal";
import { ConnectionModal } from "@/components/ConnectionModal";
import { ErrorModal } from "@/components/ErrorModal";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function ServersPage() {
  const { toast } = useToast();
  const [filters, setFilters] = React.useState<Partial<FilterType>>({
    page: 1,
    limit: 10
  });
  const [selectedServer, setSelectedServer] = React.useState<Server | null>(null);
  const [detailsOpen, setDetailsOpen] = React.useState(false);
  const [connectionOpen, setConnectionOpen] = React.useState(false);
  const [errorOpen, setErrorOpen] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState("");
  const [errorCode, setErrorCode] = React.useState("");
  const [favoriteStates, setFavoriteStates] = React.useState<Record<number, boolean>>({});

  // Fetch servers with current filters
  const { 
    data, 
    isLoading, 
    isError, 
    refetch 
  } = useQuery({
    queryKey: ['/api/servers', filters],
    queryFn: () => fetchServers(filters),
  });

  const isConnecting = false;

  // Initialize favorite states to false
  React.useEffect(() => {
    if (data?.servers) {
      const initialFavorites: Record<number, boolean> = {};
      data.servers.forEach(server => {
        initialFavorites[server.id] = false;
      });
      setFavoriteStates(initialFavorites);
    }
  }, [data?.servers]);

  // Handle filter changes
  const handleFilterChange = (newFilters: Partial<FilterType>) => {
    setFilters({
      ...filters,
      ...newFilters,
      page: 1 // Reset to first page when filters change
    });
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setFilters({
      ...filters,
      page
    });
  };

  // Handle refresh
  const handleRefresh = () => {
    refetch();
    toast({
      description: "Lista de servidores actualizada",
    });
  };

  // Open server details
  const handleOpenDetails = (serverId: number) => {
    const server = data?.servers.find(s => s.id === serverId) || null;
    if (server) {
      setSelectedServer(server);
      setDetailsOpen(true);
    }
  };

  // Handle server connection
  const handleConnect = (server: Server) => {
    setSelectedServer(server);
    setConnectionOpen(true);
  };

  // Initialize connection - disabled
  const handleInitiateConnection = () => {
    setConnectionOpen(false);
    toast({
      title: "Función deshabilitada",
      description: "La conexión a servidores SAMP ha sido removida."
    });
  };

  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="flex-grow flex flex-col bg-black/40">
        <div className="pt-6 pb-10">
          <Header onRefresh={handleRefresh} isRefreshing={isLoading} />

          <div className="container mx-auto px-4 mt-2">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
              <Link href="/">
                <Button variant="outline" className="flex items-center gap-2 bg-dark/60 border-primary/20 hover:bg-dark/80">
                  <ArrowLeft className="h-4 w-4" />
                  Volver
                </Button>
              </Link>
              <div className="flex items-center justify-center">
                <img 
                  src="/images/samp-x-logo.png" 
                  alt="SA-MP X Logo" 
                  className="w-12 h-12 object-contain mr-3 drop-shadow-[0_0_5px_rgba(131,56,236,0.7)]" 
                />
                <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                  Lista de servidores
                </h1>
              </div>
            </div>
            <p className="text-light/80 max-w-2xl mx-auto text-center mb-6">
              Explora y conecta a los servidores de San Andreas Multiplayer con facilidad.
            </p>
          </div>
        </div>

        <main className="container mx-auto px-4 pb-8 flex-grow">
          <div className="glass-card mb-6 shadow-xl">
            <ServerFilter 
              onFilterChange={handleFilterChange}
              loading={isLoading}
            />
          </div>

          {isError ? (
            <div className="text-center py-8 glass-card p-6">
              <h2 className="text-xl font-semibold text-red-400 mb-2">
                Error al cargar servidores
              </h2>
              <p className="text-light/70 mb-4">
                No se ha podido obtener la lista de servidores. Por favor, inténtalo de nuevo.
              </p>
              <button 
                onClick={() => refetch()} 
                className="px-4 py-2 bg-primary hover:bg-primary/90 text-white rounded"
              >
                Reintentar
              </button>
            </div>
          ) : isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-8">
              {Array.from({ length: 4 }).map((_, index) => (
                <div 
                  key={index} 
                  className="card-gradient rounded-lg h-40 animate-pulse"
                />
              ))}
            </div>
          ) : data?.servers.length === 0 ? (
            <div className="text-center py-10 glass-card p-6">
              <h2 className="text-xl font-semibold mb-2">No se encontraron servidores</h2>
              <p className="text-light/70">
                No hay servidores que coincidan con tus filtros. Intenta con diferentes criterios.
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-8">
                {data?.servers.map((server) => (
                  <ServerCard
                    key={server.id}
                    server={server}
                    isFavorite={favoriteStates[server.id] || false}
                    onOpenDetails={handleOpenDetails}
                    onConnect={handleConnect}
                  />
                ))}
              </div>

              <Pagination
                currentPage={filters.page || 1}
                totalPages={data?.pages || 1}
                onPageChange={handlePageChange}
                disabled={isLoading}
              />
            </>
          )}
        </main>
      </div>

      <Footer />

      {/* Modals */}
      <ServerDetailsModal
        server={selectedServer}
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        onConnect={(ip, port) => {
          setDetailsOpen(false);
          setConnectionOpen(true);
        }}
      />

      <ConnectionModal
        server={selectedServer}
        open={connectionOpen}
        onOpenChange={setConnectionOpen}
        onConnect={handleInitiateConnection}
        isConnecting={isConnecting}
      />

      <ErrorModal
        open={errorOpen}
        onOpenChange={setErrorOpen}
        errorMessage={errorMessage}
        errorCode={errorCode}
      />
    </div>
  );
}