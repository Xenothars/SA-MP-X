
import React from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MessageCircle, Info } from "lucide-react";

interface Message {
  id: number;
  content: string;
  sender: string;
  createdAt: string;
}

interface Chat {
  id: number;
  userId: string;
  status: string;
  messages: Message[];
}

export default function HelpPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = React.useState("");
  const [userId] = React.useState(() => {
    // Generar un ID aleatorio para el usuario para esta sesión
    const storedUserId = localStorage.getItem("chat_user_id");
    if (storedUserId) return storedUserId;
    
    const newUserId = `user-${Math.random().toString(36).substring(2, 9)}`;
    localStorage.setItem("chat_user_id", newUserId);
    return newUserId;
  });

  // Obtener canal activo o crear uno nuevo
  const { data: chat, isLoading, refetch } = useQuery<Chat>({
    queryKey: ['/api/help/chat', userId],
    queryFn: async () => {
      const response = await fetch(`/api/help/chat/user/${userId}`);
      if (!response.ok) {
        // Si no existe el canal, creamos uno nuevo
        if (response.status === 404) {
          const createResponse = await fetch('/api/help/chat/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId })
          });
          
          if (createResponse.ok) {
            return createResponse.json();
          }
        }
        throw new Error('Error al obtener el chat');
      }
      return response.json();
    },
  });

  // Enviar mensaje
  const { mutate: sendMessage, isPending } = useMutation({
    mutationFn: async (content: string) => {
      const response = await fetch('/api/help/chat/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          content, 
          channelId: chat?.id,
          userId 
        })
      });
      if (!response.ok) throw new Error('Network response was not ok');
      return response.json();
    },
    onSuccess: () => {
      setMessage("");
      // Recargar los mensajes
      refetch();
      toast({
        description: "Mensaje enviado correctamente",
      });
    },
    onError: () => {
      toast({
        description: "Error al enviar el mensaje",
        variant: "destructive"
      });
    }
  });

  const handleSendMessage = () => {
    if (message.trim()) {
      sendMessage(message);
    }
  };

  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="flex-grow flex flex-col bg-black/40">
        <Header onRefresh={() => refetch()} />
        
        <main className="container mx-auto px-4 py-8 flex-grow">
          <div className="max-w-2xl mx-auto">
            <div className="glass-card p-6 mb-6">
              <h1 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <MessageCircle className="h-6 w-6 text-primary" />
                Chat de Soporte
              </h1>
              <p className="text-light/70 mb-6">
                Comunícate directamente con nuestro equipo de soporte. Estamos aquí para ayudarte.
              </p>
              
              <div className="bg-dark/50 rounded-lg p-4 h-[400px] mb-4 overflow-y-auto">
                {chat?.messages?.map((msg: Message) => (
                  <div 
                    key={msg.id}
                    className={`mb-4 ${msg.sender === 'user' ? 'text-right' : ''}`}
                  >
                    <div className={`inline-block rounded-lg p-3 ${
                      msg.sender === 'user' 
                        ? 'bg-primary/20 text-white' 
                        : 'bg-light/10 text-light'
                    }`}>
                      {msg.content}
                    </div>
                    <div className="text-xs text-light/50 mt-1">
                      {new Date(msg.createdAt).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Escribe tu mensaje aquí..."
                  className="bg-dark/50"
                />
                <Button 
                  onClick={handleSendMessage}
                  className="self-end"
                >
                  Enviar
                </Button>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}
