
import React from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { User, UserPlus, Mail, UserCheck, LogOut, MessageSquare, ShieldAlert, Settings } from 'lucide-react';

export default function StaffPanel() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [role, setRole] = React.useState<string | null>(null);
  
  // Email account form
  const [emailForm, setEmailForm] = React.useState({ email: '', password: '' });
  
  // Staff member form
  const [staffForm, setStaffForm] = React.useState({ email: '', password: '', role: 'staff' });
  
  // Comprobar si el usuario está autenticado
  React.useEffect(() => {
    const staffRole = localStorage.getItem('staffRole');
    if (!staffRole) {
      setLocation('/admin/login');
    } else {
      setRole(staffRole);
    }
  }, [setLocation]);
  
  // Obtener cuentas de email
  const { data: emailAccounts, refetch: refetchEmails } = useQuery({
    queryKey: ['/api/email-accounts'],
    queryFn: async () => {
      const response = await fetch('/api/email-accounts');
      if (!response.ok) throw new Error('Failed to fetch email accounts');
      return response.json();
    },
    enabled: role === 'owner' // Solo cargar si el rol es dueño
  });
  
  // Obtener miembros del staff
  const { data: staffMembers, refetch: refetchStaff } = useQuery({
    queryKey: ['/api/staff/members'],
    queryFn: async () => {
      const response = await fetch('/api/staff/members');
      if (!response.ok) throw new Error('Failed to fetch staff members');
      return response.json();
    },
    enabled: role === 'owner' // Solo cargar si el rol es dueño
  });
  
  // Obtener chats activos
  const { data: activeChats, refetch: refetchChats } = useQuery({
    queryKey: ['/api/help/admin/chats'],
    queryFn: async () => {
      // Incluir el ID del staff en el header para autorización
      const staffId = localStorage.getItem('staffId');
      
      const response = await fetch('/api/help/admin/chats', {
        headers: {
          'Authorization': `Bearer ${staffId}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch active chats');
      return response.json();
    }
  });
  
  // Añadir cuenta de email
  const { mutate: addEmailAccount } = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/email-accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(emailForm)
      });
      if (!response.ok) throw new Error('Failed to add email account');
      return response.json();
    },
    onSuccess: () => {
      toast({ description: "Cuenta de email añadida correctamente" });
      setEmailForm({ email: '', password: '' });
      refetchEmails();
    },
    onError: () => {
      toast({
        variant: "destructive",
        description: "Error al añadir cuenta de email"
      });
    }
  });
  
  // Añadir miembro del staff
  const { mutate: addStaffMember } = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/staff/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(staffForm)
      });
      if (!response.ok) throw new Error('Failed to add staff member');
      return response.json();
    },
    onSuccess: () => {
      toast({ description: "Miembro del staff añadido correctamente" });
      setStaffForm({ email: '', password: '', role: 'staff' });
      refetchStaff();
    },
    onError: () => {
      toast({
        variant: "destructive",
        description: "Error al añadir miembro del staff"
      });
    }
  });
  
  // Eliminar cuenta de email
  const { mutate: deleteEmailAccount } = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/email-accounts/${id}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('Failed to delete email account');
      return id;
    },
    onSuccess: () => {
      toast({ description: "Cuenta de email eliminada correctamente" });
      refetchEmails();
    },
    onError: () => {
      toast({
        variant: "destructive",
        description: "Error al eliminar cuenta de email"
      });
    }
  });
  
  const handleLogout = () => {
    localStorage.removeItem('staffId');
    localStorage.removeItem('staffRole');
    localStorage.removeItem('staffEmail');
    setLocation('/admin/login');
  };
  
  // Si el usuario no está autenticado, mostrar mensaje de carga
  if (role === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-dark">
        <Card className="p-6 text-center">
          <h1 className="text-xl">Verificando acceso...</h1>
        </Card>
      </div>
    );
  }
  
  // Si el rol no es dueño y están intentando acceder al panel, mostrar acceso restringido
  if (role !== 'owner' && window.location.pathname === '/admin/panel') {
    return (
      <div 
        className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/images/alien-background.png')" }}
      >
        <div className="flex-grow flex flex-col bg-black/40">
          <Header onRefresh={() => {}} />
          
          <main className="container mx-auto px-4 py-8 flex-grow flex items-center justify-center">
            <Card className="glass-card p-6 w-full max-w-lg text-center">
              <ShieldAlert className="h-16 w-16 text-primary mx-auto mb-4" />
              <h1 className="text-xl font-semibold mb-4">Acceso Restringido</h1>
              <p className="mb-6">No tienes permiso para acceder a esta página. Solo los administradores con rango de dueño pueden acceder al panel completo.</p>
              <div className="flex justify-center gap-4">
                <Button onClick={() => setLocation('/admin/chat')}>
                  Ir a Chat de Soporte
                </Button>
                <Button variant="outline" onClick={handleLogout}>
                  Cerrar Sesión
                </Button>
              </div>
            </Card>
          </main>
          
          <Footer />
        </div>
      </div>
    );
  }
  
  // Panel para dueños (con todas las opciones)
  return (
    <div 
      className="min-h-screen flex flex-col bg-dark text-light bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: "url('/images/alien-background.png')" }}
    >
      <div className="flex-grow flex flex-col bg-black/40">
        <Header onRefresh={() => {}} />
        
        <main className="container mx-auto px-4 py-8 flex-grow">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <ShieldAlert className="h-6 w-6 text-primary" />
              Panel de Administración
            </h1>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" /> Cerrar Sesión
            </Button>
          </div>
          
          <Tabs defaultValue="chats" className="glass-card">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="chats" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" /> Chats de Soporte
              </TabsTrigger>
              <TabsTrigger value="staff" className="flex items-center gap-2">
                <UserCheck className="h-4 w-4" /> Personal
              </TabsTrigger>
              <TabsTrigger value="email" className="flex items-center gap-2">
                <Mail className="h-4 w-4" /> Cuentas de Email
              </TabsTrigger>
            </TabsList>
            
            {/* Pestaña de Chats */}
            <TabsContent value="chats" className="p-4">
              <h2 className="text-xl font-semibold mb-4">Chats Activos</h2>
              
              {activeChats && activeChats.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeChats.map((chat: any) => (
                    <Card 
                      key={chat.id} 
                      className="p-4 bg-dark/50 hover:bg-dark/70 cursor-pointer transition-colors"
                      onClick={() => setLocation(`/admin/chat/${chat.id}`)}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="font-medium">Usuario #{chat.userId}</h3>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          chat.status === 'open' 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {chat.status === 'open' ? 'Abierto' : 'En espera'}
                        </span>
                      </div>
                      <p className="text-sm text-light/70 line-clamp-2">{chat.lastMessage}</p>
                      <div className="text-xs text-light/50 mt-2">
                        {new Date(chat.timestamp).toLocaleString()}
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-light/50">
                  No hay chats activos en este momento
                </div>
              )}
            </TabsContent>
            
            {/* Pestaña de Personal */}
            <TabsContent value="staff" className="p-4">
              <div className="mb-6">
                <h2 className="text-xl font-semibold mb-4">Gestión de Personal</h2>
                
                <form onSubmit={(e) => {
                  e.preventDefault();
                  addStaffMember();
                }} className="glass-card p-4 mb-4 grid grid-cols-1 md:grid-cols-4 gap-3">
                  <Input
                    placeholder="Email"
                    value={staffForm.email}
                    onChange={(e) => setStaffForm(prev => ({ ...prev, email: e.target.value }))}
                    className="bg-dark/50 md:col-span-2"
                    required
                  />
                  <Input
                    type="password"
                    placeholder="Contraseña"
                    value={staffForm.password}
                    onChange={(e) => setStaffForm(prev => ({ ...prev, password: e.target.value }))}
                    className="bg-dark/50"
                    required
                  />
                  <div className="flex gap-2">
                    <select
                      className="flex-grow p-2 rounded-md bg-dark/50 border border-light/20 text-light"
                      value={staffForm.role}
                      onChange={(e) => setStaffForm(prev => ({ ...prev, role: e.target.value }))}
                    >
                      <option value="staff">Staff</option>
                      <option value="owner">Dueño</option>
                    </select>
                    <Button type="submit" className="shrink-0">
                      <UserPlus className="h-4 w-4" />
                    </Button>
                  </div>
                </form>
              </div>
              
              <div className="glass-card p-4">
                <h3 className="font-semibold mb-4">Listado de Personal</h3>
                <div className="space-y-2">
                  {staffMembers?.map((member: any) => (
                    <div key={member.id} className="flex justify-between items-center p-3 bg-dark/50 rounded-md">
                      <div>
                        <span>{member.email}</span>
                        <span className={`ml-2 text-xs px-2 py-1 rounded-full ${
                          member.role === 'owner' 
                            ? 'bg-primary/20 text-primary' 
                            : 'bg-blue-500/20 text-blue-400'
                        }`}>
                          {member.role === 'owner' ? 'Dueño' : 'Staff'}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" disabled>
                          <Settings className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  
                  {(!staffMembers || staffMembers.length === 0) && (
                    <div className="text-center py-4 text-light/50">
                      No hay miembros del personal registrados
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
            
            {/* Pestaña de cuentas de Email */}
            <TabsContent value="email" className="p-4">
              <div className="mb-6">
                <h2 className="text-xl font-semibold mb-4">Gestión de Cuentas de Email</h2>
                
                <form onSubmit={(e) => {
                  e.preventDefault();
                  addEmailAccount();
                }} className="glass-card p-4 mb-4 grid grid-cols-1 md:grid-cols-3 gap-3">
                  <Input
                    placeholder="Email"
                    value={emailForm.email}
                    onChange={(e) => setEmailForm(prev => ({ ...prev, email: e.target.value }))}
                    className="bg-dark/50 md:col-span-2"
                    required
                  />
                  <div className="flex gap-2">
                    <Input
                      type="password"
                      placeholder="Contraseña"
                      value={emailForm.password}
                      onChange={(e) => setEmailForm(prev => ({ ...prev, password: e.target.value }))}
                      className="bg-dark/50 flex-grow"
                      required
                    />
                    <Button type="submit" className="shrink-0">
                      <UserPlus className="h-4 w-4" />
                    </Button>
                  </div>
                </form>
              </div>
              
              <div className="glass-card p-4">
                <h3 className="font-semibold mb-4">Listado de Cuentas</h3>
                <div className="space-y-2">
                  {emailAccounts?.map((account: any) => (
                    <div key={account.id} className="flex justify-between items-center p-3 bg-dark/50 rounded-md">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-primary" />
                        <span>{account.email}</span>
                      </div>
                      <Button 
                        variant="destructive" 
                        size="sm"
                        onClick={() => deleteEmailAccount(account.id)}
                      >
                        Eliminar
                      </Button>
                    </div>
                  ))}
                  
                  {(!emailAccounts || emailAccounts.length === 0) && (
                    <div className="text-center py-4 text-light/50">
                      No hay cuentas de correo registradas
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </main>
        
        <Footer />
      </div>
    </div>
  );
}
