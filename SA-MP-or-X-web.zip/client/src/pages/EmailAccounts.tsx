
import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Trash2 } from "lucide-react";

interface EmailAccount {
  id: number;
  email: string;
  createdAt: string;
}

export default function EmailAccounts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");

  const { data: accounts, isLoading } = useQuery({
    queryKey: ['/api/email-accounts'],
    queryFn: async () => {
      const response = await fetch('/api/email-accounts');
      if (!response.ok) throw new Error('Network response was not ok');
      return response.json();
    },
  });

  const addAccount = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/email-accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (!response.ok) throw new Error('Failed to add account');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/email-accounts'] });
      setEmail("");
      setPassword("");
      toast({ description: "Cuenta de correo agregada exitosamente" });
    },
    onError: () => {
      toast({
        description: "Error al agregar la cuenta de correo",
        variant: "destructive"
      });
    }
  });

  const deleteAccount = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/email-accounts/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete account');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/email-accounts'] });
      toast({ description: "Cuenta eliminada exitosamente" });
    },
    onError: () => {
      toast({
        description: "Error al eliminar la cuenta",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        description: "Por favor completa todos los campos",
        variant: "destructive"
      });
      return;
    }
    addAccount.mutate();
  };

  return (
    <div className="min-h-screen flex flex-col bg-dark text-light">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Gestionar Cuentas de Correo</h1>
          
          <form onSubmit={handleSubmit} className="glass-card p-6 mb-8">
            <div className="space-y-4">
              <div>
                <label className="block mb-2">Correo Electrónico</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ejemplo@correo.com"
                />
              </div>
              
              <div>
                <label className="block mb-2">Contraseña</label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Contraseña"
                />
              </div>
              
              <Button type="submit" className="w-full">
                Agregar Cuenta
              </Button>
            </div>
          </form>
          
          <div className="glass-card p-6">
            <h2 className="text-xl font-semibold mb-4">Cuentas Registradas</h2>
            
            {isLoading ? (
              <p>Cargando...</p>
            ) : accounts?.length === 0 ? (
              <p className="text-light/70">No hay cuentas registradas</p>
            ) : (
              <div className="space-y-4">
                {accounts?.map((account: EmailAccount) => (
                  <div key={account.id} className="flex items-center justify-between p-4 bg-dark/50 rounded-lg">
                    <div>
                      <p className="font-medium">{account.email}</p>
                      <p className="text-sm text-light/70">
                        Agregado el: {new Date(account.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Button
                      variant="destructive"
                      size="icon"
                      onClick={() => deleteAccount.mutate(account.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
