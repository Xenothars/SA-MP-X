import React from "react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Gamepad2, RefreshCw } from "lucide-react";

interface HeaderProps {
  onRefresh: () => void;
  isRefreshing?: boolean;
}

export function Header({ onRefresh, isRefreshing }: HeaderProps) {
  return (
    <header className="backdrop-blur-sm bg-medium/80 shadow-xl border-b border-primary/10">
      <div className="container mx-auto px-4 py-3 flex flex-wrap items-center justify-between">
        <div className="flex items-center">
          <div className="bg-primary/20 p-2 rounded-full mr-3">
            <Gamepad2 className="text-primary h-6 w-6" />
          </div>
          <Link href="/">
            <span className="text-2xl font-bold text-gradient hover:opacity-90 transition-opacity cursor-pointer">
              SA-MP | X
            </span>
          </Link>
        </div>
        <div className="flex items-center space-x-4 mt-4 md:mt-0">
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={onRefresh}
            disabled={isRefreshing}
            className="flex items-center text-sm shadow-lg"
          >
            <RefreshCw className={`mr-1 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            {isRefreshing ? "Actualizando..." : "Actualizar"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="text-sm mr-2"
            onClick={() => window.location.href = '/contact'}
          >
            Contacto
          </Button>
          <Link href="/help">
            <Button
              variant="outline"
              size="sm"
              className="text-sm"
            >
              Ayuda
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
}