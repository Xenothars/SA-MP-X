import React from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ServerWithPlayers } from "@shared/schema";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { X, LogIn } from "lucide-react";

interface ServerDetailsModalProps {
  server: ServerWithPlayers | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConnect: (ip: string, port: number) => void;
}

export function ServerDetailsModal({ 
  server, 
  open, 
  onOpenChange,
  onConnect 
}: ServerDetailsModalProps) {
  if (!server) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto max-w-3xl">
        <DialogHeader>
          <DialogTitle>{server.name}</DialogTitle>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onOpenChange(false)}
            className="absolute right-4 top-4 text-light hover:text-white"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <div className="p-6">
          <div className="flex flex-col md:flex-row gap-6 mb-6">
            <div className="md:w-1/3">
              <div className="bg-dark p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Información del servidor</h3>
                <div className="text-sm space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-light/70">Dirección:</span>
                    <span className="font-medium">{server.ip}:{server.port}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-light/70">Jugadores:</span>
                    <span className="font-medium">{server.currentPlayers}/{server.maxPlayers}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-light/70">Ping:</span>
                    <span className={server.ping && server.ping < 50 ? "text-green-400" : server.ping && server.ping < 100 ? "text-yellow-400" : "text-red-400"}>
                      {server.ping ? `${server.ping}ms` : "--"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-light/70">Modo:</span>
                    <span className="font-medium">{server.gameMode || "--"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-light/70">Idioma:</span>
                    <span className="font-medium">{server.language || "--"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-light/70">Versión:</span>
                    <span className="font-medium">{server.version || "--"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-light/70">Estado:</span>
                    <Badge variant={server.isOnline ? "online" : "offline"} size="sm">
                      {server.isOnline ? "Online" : "Offline"}
                    </Badge>
                  </div>
                </div>
                <div className="mt-4">
                  <Button
                    variant="accent" 
                    className="w-full flex items-center justify-center"
                    onClick={() => onConnect(server.ip, server.port)}
                    disabled={!server.isOnline}
                  >
                    <LogIn className="mr-1 h-4 w-4" />
                    Conectar ahora
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="md:w-2/3">
              <div className="mb-6">
                <h3 className="font-semibold mb-2">Descripción</h3>
                <div className="bg-dark p-4 rounded-lg text-sm">
                  {server.description ? (
                    server.description.split('\n\n').map((paragraph, index) => (
                      <p key={index} className={index > 0 ? "mt-2" : ""}>
                        {paragraph}
                      </p>
                    ))
                  ) : (
                    <p>No hay descripción disponible.</p>
                  )}
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Reglas del servidor</h3>
                <div className="bg-dark p-4 rounded-lg text-sm">
                  {server.rules ? (
                    <ul className="list-disc pl-4 space-y-1">
                      {server.rules.split('\n').map((rule, index) => (
                        <li key={index}>{rule}</li>
                      ))}
                    </ul>
                  ) : (
                    <p>No hay reglas disponibles.</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">
              Jugadores conectados ({server.currentPlayers}/{server.maxPlayers})
            </h3>
            <div className="bg-dark p-4 rounded-lg overflow-x-auto">
              {server.players && server.players.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Nivel</TableHead>
                      <TableHead>Ping</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {server.players.map((player, index) => (
                      <TableRow key={player.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{player.name}</TableCell>
                        <TableCell>{player.level || "--"}</TableCell>
                        <TableCell>{player.ping ? `${player.ping}ms` : "--"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center text-light/50 py-4">
                  No hay jugadores conectados
                </div>
              )}
              
              {server.players && server.players.length > 0 && server.players.length < server.currentPlayers && (
                <div className="mt-2 text-center text-xs text-light/50">
                  Mostrando {server.players.length} de {server.currentPlayers} jugadores
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
