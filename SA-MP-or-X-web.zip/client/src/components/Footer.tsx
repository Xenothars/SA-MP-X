import React from "react";
import { Link } from "wouter";
import { Github, Heart, MessageSquare, FileText, ShieldAlert } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gradient-to-b from-transparent to-primary/5 mt-10 border-t border-primary/10">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <div className="flex items-center">
              <Heart className="h-4 w-4 text-primary mr-2" />
              <p className="text-sm text-light/70">
                © {currentYear} SA-MP | X - Todos los derechos reservados
              </p>
            </div>
            <p className="text-xs text-light/50 mt-2">
              Esta aplicación no está afiliada con Rockstar Games o SA-MP
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/contact">
              <span className="flex items-center text-light hover:text-primary text-sm transition-colors cursor-pointer">
                <MessageSquare className="h-4 w-4 mr-1" />
                Contacto
              </span>
            </Link>
            <Link href="/help">
              <span className="flex items-center text-light hover:text-primary text-sm transition-colors cursor-pointer">
                <FileText className="h-4 w-4 mr-1" />
                Ayuda
              </span>
            </Link>
            <Link href="/terms">
              <span className="flex items-center text-light hover:text-primary text-sm transition-colors cursor-pointer">
                <FileText className="h-4 w-4 mr-1" />
                Términos
              </span>
            </Link>
            <Link href="/privacy">
              <span className="flex items-center text-light hover:text-primary text-sm transition-colors cursor-pointer">
                <ShieldAlert className="h-4 w-4 mr-1" />
                Privacidad
              </span>
            </Link>
            <Link href="/customize">
              <span className="flex items-center text-light hover:text-primary text-sm transition-colors cursor-pointer">
                <Github className="h-4 w-4 mr-1" />
                Personalizar
              </span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
