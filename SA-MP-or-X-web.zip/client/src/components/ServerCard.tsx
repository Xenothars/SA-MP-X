import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { Server } from "@shared/schema";
import { Gamepad as GamepadIcon, Globe as GlobeIcon, Hash, LogIn, Info as InfoIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ServerCardProps {
  server: Server;
  isFavorite?: boolean; 
  onOpenDetails: (serverId: number) => void;
  onConnect: (server: Server) => void;
}

export function ServerCard({ server, isFavorite, onOpenDetails, onConnect }: ServerCardProps) {
  const { toast } = useToast();
  const playerPercentage = server.maxPlayers ? Math.floor((server.currentPlayers / server.maxPlayers) * 100) : 0;

  const getServerIcon = (gameMode?: string) => {
    switch (gameMode?.toLowerCase()) {
      case 'roleplay':
        return <GamepadIcon className="text-accent" />;
      case 'freeroam':
        return <GlobeIcon className="text-secondary" />;
      case 'carreras':
        return <GamepadIcon className="text-primary" />;
      default:
        return <GamepadIcon className="text-accent" />;
    }
  };

  return (
    <Card className="card-gradient hover:shadow-lg transition-all duration-300">
      <div className="flex items-center justify-between p-4 border-b border-primary/10">
        <div className="flex items-center">
          <div className="mr-3">
            <div className="h-14 w-14 rounded-lg bg-primary/10 backdrop-blur-sm flex items-center justify-center shadow-inner">
              {getServerIcon(server.gameMode)}
            </div>
          </div>
          <div>
            <h3 className="font-bold text-white text-lg">{server.name}</h3>
            <div className="flex items-center text-xs text-light/70 flex-wrap gap-2 mt-1">
              <span className="flex items-center bg-dark/40 rounded-full px-2 py-0.5">
                <Hash className="w-3 h-3 mr-1 text-primary/70" />
                {server.ip}:{server.port}
              </span>
              {server.language && (
                <span className="flex items-center bg-dark/40 rounded-full px-2 py-0.5">
                  <GlobeIcon className="w-3 h-3 mr-1 text-primary/70" />
                  {server.language}
                </span>
              )}
              {server.gameMode && (
                <span className="flex items-center bg-dark/40 rounded-full px-2 py-0.5">
                  <GamepadIcon className="w-3 h-3 mr-1 text-primary/70" />
                  {server.gameMode}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center">
          <Badge variant={server.isOnline ? "online" : "offline"} className="shadow-md">
            <span className="w-2 h-2 bg-online rounded-full mr-1"></span>
            {server.isOnline ? "Online" : "Offline"}
          </Badge>
        </div>
      </div>
      <div className="p-4 bg-gradient-to-br from-transparent to-dark/30">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center text-sm">
            <GamepadIcon className="mr-1 h-4 w-4 text-primary/70" />
            <span className="font-medium">
              {server.currentPlayers}/{server.maxPlayers} jugadores
            </span>
          </div>
          {server.ping ? (
            <div className="flex items-center text-sm">
              <InfoIcon className="mr-1 h-4 w-4 text-primary/70" />
              <span className={server.ping < 50 ? "text-green-400" : server.ping < 100 ? "text-yellow-400" : "text-red-400"}>
                {server.ping}ms
              </span>
            </div>
          ) : (
            <div className="flex items-center text-sm">
              <InfoIcon className="mr-1 h-4 w-4 text-primary/70" />
              <span className="text-red-400">--</span>
            </div>
          )}
        </div>
        <Progress value={playerPercentage} className="mb-4 h-2" />
        <div className="flex justify-between items-center">
          <Button 
            variant="dark"
            size="sm"
            onClick={() => onOpenDetails(server.id)}
            className="shadow-md hover:shadow-lg transition-shadow"
          >
            Detalles
          </Button>
        </div>
      </div>
    </Card>
  );
}