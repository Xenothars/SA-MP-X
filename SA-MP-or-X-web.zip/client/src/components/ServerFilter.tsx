import React from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ServerFilter as ServerFilterType } from "@shared/schema";
import { Search, Filter } from "lucide-react";

interface ServerFilterProps {
  onFilterChange: (filters: Partial<ServerFilterType>) => void;
  loading?: boolean;
}

export function ServerFilter({ onFilterChange, loading }: ServerFilterProps) {
  const [search, setSearch] = React.useState("");
  const [gameMode, setGameMode] = React.useState("all");
  const [status, setStatus] = React.useState("all");

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  };

  const handleGameModeChange = (value: string) => {
    setGameMode(value);
  };

  const handleStatusChange = (value: string) => {
    setStatus(value);
  };

  const applyFilters = () => {
    onFilterChange({
      search,
      gameMode,
      status: status as "all" | "online" | "notfull" | "favorites"
    });
  };

  return (
    <div className="p-6 rounded-lg shadow-lg backdrop-blur-sm bg-medium/40 border border-primary/10">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="relative flex-grow">
          <Input
            type="text"
            placeholder="Buscar servidor..."
            value={search}
            onChange={handleSearch}
            className="w-full pl-10 bg-dark/60 border-primary/20 focus:border-primary focus:ring-2 focus:ring-primary/20"
          />
          <Search className="absolute left-3 top-2.5 text-primary/60 h-4 w-4" />
        </div>
        <div className="flex flex-wrap gap-3">
          <Select value={gameMode} onValueChange={handleGameModeChange}>
            <SelectTrigger className="w-full sm:w-auto min-w-[150px] bg-dark/60 border-primary/20">
              <SelectValue placeholder="Todos los modos" />
            </SelectTrigger>
            <SelectContent className="bg-medium border-primary/20">
              <SelectItem value="all">Todos los modos</SelectItem>
              <SelectItem value="Roleplay">Roleplay</SelectItem>
              <SelectItem value="Freeroam">Freeroam</SelectItem>
              <SelectItem value="Stunt">Stunt</SelectItem>
              <SelectItem value="Carreras">Carreras</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={status} onValueChange={handleStatusChange}>
            <SelectTrigger className="w-full sm:w-auto min-w-[150px] bg-dark/60 border-primary/20">
              <SelectValue placeholder="Todos" />
            </SelectTrigger>
            <SelectContent className="bg-medium border-primary/20">
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="online">Solo Online</SelectItem>
              <SelectItem value="notfull">No Llenos</SelectItem>
              <SelectItem value="favorites">Favoritos</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="secondary" 
            onClick={applyFilters}
            disabled={loading}
            className="flex items-center shadow-md hover:shadow-lg transition-shadow"
          >
            <Filter className="mr-1 h-4 w-4" />
            {loading ? "Aplicando..." : "Filtrar"}
          </Button>
        </div>
      </div>
    </div>
  );
}
