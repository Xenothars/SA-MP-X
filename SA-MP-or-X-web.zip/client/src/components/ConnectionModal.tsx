import { type Server } from "@shared/schema";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

interface ConnectionModalProps {
  server: Server | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConnect: () => void;
  isConnecting?: boolean;
}

export function ConnectionModal({ 
  server, 
  open, 
  onOpenChange,
  onConnect,
  isConnecting = false
}: ConnectionModalProps) {
  if (!server) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Conectar a servidor</DialogTitle>
          <DialogDescription>
            Esta característica ha sido deshabilitada.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 py-4">
          <AlertTriangle className="h-10 w-10 text-yellow-500" />
          <p className="text-light/70">
            La funcionalidad de conexión a servidores SAMP ha sido removida.
          </p>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cerrar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}