import React from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, AlertCircle } from "lucide-react";

interface ErrorModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  errorMessage?: string;
  errorCode?: string;
}

export function ErrorModal({ 
  open, 
  onOpenChange,
  errorMessage = "No se pudo conectar al servidor.",
  errorCode = "CONNECTION_TIMED_OUT"
}: ErrorModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Error de conexión</DialogTitle>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onOpenChange(false)}
            className="absolute right-4 top-4 text-light hover:text-white"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <div className="p-6 pt-2">
          <div className="flex items-start mb-4">
            <AlertCircle className="h-5 w-5 text-red-500 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm">{errorMessage} Por favor, verifica lo siguiente:</p>
              <ul className="list-disc pl-5 mt-2 text-sm text-light/80">
                <li>Que GTA San Andreas esté instalado correctamente</li>
                <li>Que SA-MP 0.3.7 esté instalado</li>
                <li>Que el servidor esté en línea</li>
                <li>Que tu conexión a Internet esté funcionando</li>
              </ul>
            </div>
          </div>
          
          <div className="bg-dark p-3 rounded border border-light/10 text-sm">
            <p className="text-light/70">
              Código de error: <span className="font-mono">{errorCode}</span>
            </p>
          </div>
          
          <DialogFooter className="sm:justify-end mt-4">
            <Button 
              variant="primary" 
              onClick={() => onOpenChange(false)}
            >
              Entendido
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}
