import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import ServerDetails from "@/pages/ServerDetails";
import ServersPage from "@/pages/ServersPage";
import ContactPage from "@/pages/ContactPage";
import HelpPage from "@/pages/HelpPage";
import TermsPage from "@/pages/TermsPage";
import PrivacyPage from "@/pages/PrivacyPage";
import CustomizePage from "@/pages/CustomizePage";
import LaunchersPage from "@/pages/LaunchersPage";
import AdminChat from "@/pages/AdminChat";
import EmailAccounts from "@/pages/EmailAccounts";
import StaffLogin from "@/pages/StaffLogin";
import StaffPanel from "@/pages/StaffPanel";


function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/servers" component={ServersPage} />
      <Route path="/servers/:id" component={ServerDetails} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/help" component={HelpPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/customize" component={CustomizePage} />
      <Route path="/launchers" component={LaunchersPage} />
      
      {/* Rutas de administración */}
      <Route path="/admin/login" component={StaffLogin} />
      <Route path="/admin/panel" component={StaffPanel} />
      <Route path="/admin/chat" component={AdminChat} />
      <Route path="/admin/chat/:chatId" component={AdminChat} /> {/* Ruta para ver un chat específico */}
      <Route path="/admin/email" component={EmailAccounts} />
      
      {/* Legacy routes - for backward compatibility */}
      <Route path="/email-accounts" component={EmailAccounts} />
      <Route path="/staff/login" component={StaffLogin} />
      <Route path="/staff/panel" component={StaffPanel} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;