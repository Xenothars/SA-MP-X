import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Server table
export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ip: text("ip").notNull(),
  port: integer("port").notNull(),
  gameMode: text("game_mode"),
  language: text("language"),
  passwordProtected: boolean("password_protected").default(false),
  maxPlayers: integer("max_players").default(0),
  currentPlayers: integer("current_players").default(0),
  ping: integer("ping"),
  version: text("version"),
  description: text("description"),
  rules: text("rules"),
  isOnline: boolean("is_online").default(true),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Player table
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  name: text("name").notNull(),
  level: integer("level"),
  ping: integer("ping"),
});

// Favorites table
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  serverId: integer("server_id").notNull(),
});

// Email accounts table
export const emailAccounts = pgTable("email_accounts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertEmailAccountSchema = createInsertSchema(emailAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type EmailAccount = typeof emailAccounts.$inferSelect;
export type InsertEmailAccount = z.infer<typeof insertEmailAccountSchema>;

// Staff table
export const staffAccounts = pgTable("staff_accounts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(), // 'owner' or 'staff'
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat channels table
export const chatChannels = pgTable("chat_channels", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  userIp: text("user_ip"),
  status: text("status").notNull().default('open'),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  channelId: integer("channel_id").notNull(),
  content: text("content").notNull(),
  sender: text("sender").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Define schemas for insertions
export const insertServerSchema = createInsertSchema(servers).omit({
  id: true,
  lastUpdated: true,
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
});

// Define types for our models
export type Server = typeof servers.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;

export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;

// Define the ServerWithPlayers type for joining server with players
export type ServerWithPlayers = Server & {
  players?: Player[];
};

// Define filter types
export const serverFilterSchema = z.object({
  search: z.string().optional(),
  gameMode: z.string().optional(),
  status: z.enum(['all', 'online', 'notfull', 'favorites']).optional(),
  page: z.number().default(1),
  limit: z.number().default(10),
});

export type ServerFilter = z.infer<typeof serverFilterSchema>;

// Staff schema
export const insertStaffAccountSchema = createInsertSchema(staffAccounts).omit({
  id: true,
  createdAt: true,
});

export type StaffAccount = typeof staffAccounts.$inferSelect;
export type InsertStaffAccount = z.infer<typeof insertStaffAccountSchema>;

// Chat schemas
export const insertChatChannelSchema = createInsertSchema(chatChannels).omit({
  id: true,
  createdAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true, 
  createdAt: true,
  isRead: true, // Por defecto, los nuevos mensajes no están leídos
});

export type ChatChannel = typeof chatChannels.$inferSelect;
export type InsertChatChannel = z.infer<typeof insertChatChannelSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

// Combined types for API responses
export type Message = {
  id: number;
  content: string;
  sender: string;
  createdAt: Date;
  isRead?: boolean;
};

export type Chat = {
  id: number;
  userId: string;
  status: string;
  createdAt: Date;
  messages: Message[];
};
