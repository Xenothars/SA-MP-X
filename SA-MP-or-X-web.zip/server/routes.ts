import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { serverFilterSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for servers
  app.get("/api/servers", async (req: Request, res: Response) => {
    try {
      const filters = serverFilterSchema.parse({
        search: req.query.search as string | undefined,
        gameMode: req.query.gameMode as string | undefined,
        status: req.query.status as string | undefined,
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 10
      });

      const { servers, total } = await storage.getServers(filters);
      
      res.json({
        servers,
        total,
        page: filters.page,
        pages: Math.ceil(total / filters.limit)
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid filter parameters", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to fetch servers" });
    }
  });

  app.get("/api/servers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid server ID" });
      }

      const server = await storage.getServer(id);
      if (!server) {
        return res.status(404).json({ message: "Server not found" });
      }

      res.json(server);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch server details" });
    }
  });

  // API routes for favorites
  app.get("/api/favorites", async (req: Request, res: Response) => {
    try {
      // For demonstration, use a fixed userId
      const userId = req.query.userId as string || "user-1";
      
      const favorites = await storage.getFavorites(userId);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", async (req: Request, res: Response) => {
    try {
      // For demonstration, use a fixed userId
      const userId = req.body.userId || "user-1";
      const serverId = parseInt(req.body.serverId);
      
      if (isNaN(serverId)) {
        return res.status(400).json({ message: "Invalid server ID" });
      }

      // Check if the server exists
      const server = await storage.getServer(serverId);
      if (!server) {
        return res.status(404).json({ message: "Server not found" });
      }

      // Check if already a favorite
      const isFavorite = await storage.isFavorite(userId, serverId);
      if (isFavorite) {
        return res.status(409).json({ message: "Server already in favorites" });
      }

      const favorite = await storage.addFavorite({ userId, serverId });
      res.status(201).json(favorite);
    } catch (error) {
      res.status(500).json({ message: "Failed to add favorite" });
    }
  });

  app.delete("/api/favorites/:serverId", async (req: Request, res: Response) => {
    try {
      // For demonstration, use a fixed userId
      const userId = req.query.userId as string || "user-1";
      const serverId = parseInt(req.params.serverId);
      
      if (isNaN(serverId)) {
        return res.status(400).json({ message: "Invalid server ID" });
      }

      const success = await storage.removeFavorite(userId, serverId);
      if (!success) {
        return res.status(404).json({ message: "Favorite not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  // API route for checking favorite status
  app.get("/api/favorites/check/:serverId", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string || "user-1";
      const serverId = parseInt(req.params.serverId);
      
      if (isNaN(serverId)) {
        return res.status(400).json({ message: "Invalid server ID" });
      }

      const isFavorite = await storage.isFavorite(userId, serverId);
      res.json({ isFavorite });
    } catch (error) {
      res.status(500).json({ message: "Failed to check favorite status" });
    }
  });

  

  // Create HTTP server
  const httpServer = createServer(app);
  // Help chat routes
  // Staff authentication routes
  app.post("/api/staff/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      const staff = await storage.authenticateStaff(email, password);
      
      if (staff) {
        res.json({ success: true, staff });
      } else {
        res.status(401).json({ message: "Invalid credentials" });
      }
    } catch (error) {
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  // Staff management routes (owners only)
  app.post("/api/staff/members", async (req: Request, res: Response) => {
    try {
      const { email, password, role } = req.body;
      const staff = await storage.addStaffMember(email, password, role);
      res.status(201).json(staff);
    } catch (error) {
      res.status(500).json({ message: "Failed to add staff member" });
    }
  });

  app.get("/api/staff/members", async (req: Request, res: Response) => {
    try {
      const members = await storage.getStaffMembers();
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to get staff members" });
    }
  });

  // Chat routes
  app.get("/api/help/chat/user/:userId", async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      const userIp = req.ip || req.socket.remoteAddress || 'unknown';
      
      // Primero verificamos si existe un canal para esta IP
      let channel = await storage.getChatChannelByIp(userIp);
      
      // Si no hay canal por IP o está cerrado, buscamos por userId
      if (!channel || channel.status === 'closed') {
        channel = await storage.getChatChannelByUserId(userId);
      }
      
      if (!channel) {
        return res.status(404).json({ message: "Chat channel not found" });
      }
      
      // Obtener mensajes del canal
      const messages = await storage.getChatMessages(channel.id);
      
      res.json({
        id: channel.id,
        userId: channel.userId, // Usamos el userId del canal, no del parámetro
        status: channel.status,
        messages: messages
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get chat" });
    }
  });
  
  app.post("/api/help/chat/create", async (req: Request, res: Response) => {
    try {
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      // Obtener la dirección IP del usuario
      const userIp = req.ip || req.socket.remoteAddress || 'unknown';
      
      // Verificar si ya existe un chat para esta IP
      const existingChannel = await storage.getChatChannelByIp(userIp);
      
      if (existingChannel && existingChannel.status !== 'closed') {
        // Si ya existe un canal activo para esta IP, devolver ese
        const messages = await storage.getChatMessages(existingChannel.id);
        
        return res.status(200).json({
          id: existingChannel.id,
          userId: existingChannel.userId,
          status: existingChannel.status,
          messages: messages
        });
      }
      
      // Crear un nuevo canal para el usuario con su IP
      const channel = await storage.createChannel(userId, userIp);
      
      res.status(201).json({
        id: channel.id,
        userId: userId,
        status: channel.status,
        messages: []
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to create chat channel" });
    }
  });

  app.post("/api/help/chat/message", async (req: Request, res: Response) => {
    try {
      const { content, channelId, userId } = req.body;
      const userIp = req.ip || req.socket.remoteAddress || 'unknown';
      
      if (!content) {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      // Buscar canal existente o crear uno nuevo
      let channel = channelId;
      
      if (!channel) {
        // Primero buscamos si existe un canal activo para esta IP
        const ipChannel = await storage.getChatChannelByIp(userIp);
        
        if (ipChannel && ipChannel.status !== 'closed') {
          channel = ipChannel.id;
        } else if (userId) {
          // Si no hay canal por IP o está cerrado, buscamos por userId
          const userIdChannel = await storage.getChatChannelByUserId(userId);
          
          if (userIdChannel && userIdChannel.status !== 'closed') {
            channel = userIdChannel.id;
          } else {
            // Crear un nuevo canal si no existe uno activo
            const newChannel = await storage.createChannel(userId, userIp);
            channel = newChannel.id;
          }
        }
      }
      
      if (!channel) {
        return res.status(400).json({ message: "Channel ID or User ID is required" });
      }

      const message = await storage.addChatMessage({
        content,
        sender: "user",
        channelId: channel
      });
      
      res.json({ message, channelId: channel });
    } catch (error) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  // Rutas para el panel de administración
  app.post("/api/help/admin/message", async (req: Request, res: Response) => {
    try {
      const { content, channelId, staffId } = req.body;
      
      if (!content || !channelId) {
        return res.status(400).json({ message: "Message content and channel ID are required" });
      }
      
      // Verificar si el canal existe
      const channel = await storage.getChatChannelById(channelId);
      
      if (!channel) {
        return res.status(404).json({ message: "Chat channel not found" });
      }
      
      // Añadir mensaje del staff
      const message = await storage.addChatMessage({
        content,
        sender: "staff",
        channelId,
        staffId
      });
      
      res.json({ message });
    } catch (error) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.get("/api/help/admin/chats", async (req: Request, res: Response) => {
    try {
      // Verificar autenticación
      const { authorization } = req.headers;
      
      if (!authorization) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // En una aplicación real, verificaríamos un token
      // Por ahora, simplemente verificamos que haya un header de autorización
      
      const chats = await storage.getActiveChats();
      res.json(chats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get chats" });
    }
  });
  
  // Obtener un chat específico para el admin
  app.get("/api/help/admin/chat/:channelId", async (req: Request, res: Response) => {
    try {
      const channelId = parseInt(req.params.channelId);
      
      if (isNaN(channelId)) {
        return res.status(400).json({ message: "Invalid channel ID" });
      }
      
      // Verificar si el canal existe
      const channel = await storage.getChatChannelById(channelId);
      
      if (!channel) {
        return res.status(404).json({ message: "Chat channel not found" });
      }
      
      // Obtener mensajes del canal
      const messages = await storage.getChatMessages(channelId);
      
      res.json({
        id: channel.id,
        userId: channel.userId,
        status: channel.status,
        createdAt: channel.createdAt,
        messages: messages
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get chat" });
    }
  });
  
  // Actualizar el estado de un chat
  app.patch("/api/help/admin/chat/:channelId/status", async (req: Request, res: Response) => {
    try {
      const channelId = parseInt(req.params.channelId);
      const { status } = req.body;
      
      if (isNaN(channelId)) {
        return res.status(400).json({ message: "Invalid channel ID" });
      }
      
      if (!status || !['open', 'waiting', 'closed'].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      // Verificar si el canal existe
      const channel = await storage.getChatChannelById(channelId);
      
      if (!channel) {
        return res.status(404).json({ message: "Chat channel not found" });
      }
      
      // Actualizar el estado del canal
      const success = await storage.updateChatStatus(channelId, status);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to update chat status" });
      }
      
      res.json({ 
        message: "Chat status updated successfully",
        channelId,
        status
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to update chat status" });
    }
  });
  
  // Marcar mensajes como leídos
  app.patch("/api/help/admin/chat/:channelId/read", async (req: Request, res: Response) => {
    try {
      const channelId = parseInt(req.params.channelId);
      
      if (isNaN(channelId)) {
        return res.status(400).json({ message: "Invalid channel ID" });
      }
      
      // Verificar si el canal existe
      const channel = await storage.getChatChannelById(channelId);
      
      if (!channel) {
        return res.status(404).json({ message: "Chat channel not found" });
      }
      
      // Marcar como leídos todos los mensajes del usuario
      const success = await storage.markMessagesAsRead(channelId);
      
      if (!success) {
        return res.status(500).json({ message: "Failed to mark messages as read" });
      }
      
      res.json({ 
        message: "Messages marked as read successfully",
        channelId
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark messages as read" });
    }
  });

  // Email accounts endpoints
  app.post("/api/email-accounts", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      const result = await storage.addEmailAccount({ email, password });
      res.status(201).json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to add email account" });
    }
  });

  app.get("/api/email-accounts", async (req: Request, res: Response) => {
    try {
      const accounts = await storage.getEmailAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get email accounts" });
    }
  });

  app.delete("/api/email-accounts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteEmailAccount(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete email account" });
    }
  });

  return httpServer;
}
