import { servers, players, favorites, chatChannels, chatMessages, emailAccounts, 
  type Server, type InsertServer, type Player, type InsertPlayer, 
  type Favorite, type InsertFavorite, type ServerWithPlayers, type ServerFilter,
  type ChatChannel, type ChatMessage, type StaffAccount, type EmailAccount
} from "@shared/schema";
import { staffAccounts } from "@shared/schema";
import { db } from "./db";
import { eq, and, ilike, or, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Server methods
  getServers(filter?: ServerFilter): Promise<{ servers: Server[], total: number }>;
  getServer(id: number): Promise<ServerWithPlayers | null>;
  
  // Favorites methods
  getFavorites(userId: string): Promise<Server[]>;
  isFavorite(userId: string, serverId: number): Promise<boolean>;
  addFavorite(favorite: { userId: string; serverId: number }): Promise<Favorite>;
  removeFavorite(userId: string, serverId: number): Promise<boolean>;
  
  // Staff methods
  authenticateStaff(email: string, password: string): Promise<StaffAccount | null>;
  addStaffMember(email: string, password: string, role: string): Promise<StaffAccount>;
  getStaffMembers(): Promise<StaffAccount[]>;
  
  // Chat methods
  createChannel(userId: string, userIp?: string): Promise<ChatChannel>;
  getChatChannelByUserId(userId: string): Promise<ChatChannel | null>;
  getChatChannelByIp(userIp: string): Promise<ChatChannel | null>;
  getChatChannelById(channelId: number): Promise<ChatChannel | null>;
  getChatMessages(channelId: number): Promise<ChatMessage[]>;
  addChatMessage(message: { content: string, sender: string, channelId: number, staffId?: string }): Promise<ChatMessage>;
  getActiveChats(): Promise<any[]>;
  getStaffChats(): Promise<any[]>;
  updateChatStatus(channelId: number, status: string): Promise<boolean>;
  markMessagesAsRead(channelId: number): Promise<boolean>;
  
  // Email accounts methods
  addEmailAccount(account: { email: string, password: string }): Promise<EmailAccount>;
  getEmailAccounts(): Promise<EmailAccount[]>;
  deleteEmailAccount(id: number): Promise<void>;
}

// Importación de una librería para hash de contraseñas (bcryptjs sería ideal, pero usamos crypto para simplicidad)
import * as crypto from "crypto";

// Función para hacer hash de contraseñas
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Implementación del almacenamiento usando la base de datos PostgreSQL
export const storage: IStorage = {
  // Server methods
  getServers: async (filters: Partial<ServerFilter> = {}) => {
    try {
      // Preparar las condiciones de búsqueda
      let query = db.select().from(servers);
      
      // Aplicar filtros
      if (filters.search) {
        const searchTerm = `%${filters.search}%`;
        query = query.where(
          or(
            ilike(servers.name, searchTerm),
            ilike(servers.gameMode || '', searchTerm),
            ilike(servers.description || '', searchTerm)
          )
        );
      }
      
      if (filters.gameMode) {
        query = query.where(eq(servers.gameMode || '', filters.gameMode));
      }
      
      if (filters.status === 'online') {
        query = query.where(eq(servers.isOnline, true));
      } else if (filters.status === 'notfull') {
        query = query.where(
          and(
            eq(servers.isOnline, true),
            sql`${servers.currentPlayers} < ${servers.maxPlayers}`
          )
        );
      } else if (filters.status === 'favorites') {
        // La lógica para favoritos se maneja en otra parte, este caso se ignora en esta consulta
      }
      
      // Contar el total de registros que coinciden con los filtros
      const countResult = await db.select({ count: sql<number>`count(*)` }).from(servers);
      const total = countResult[0]?.count || 0;
      
      // Aplicar paginación
      const page = filters.page || 1;
      const limit = filters.limit || 10;
      const offset = (page - 1) * limit;
      
      query = query.limit(limit).offset(offset);
      
      // Ejecutar la consulta
      const result = await query;
      
      return {
        servers: result,
        total
      };
    } catch (error) {
      console.error("Error fetching servers:", error);
      return { servers: [], total: 0 };
    }
  },
  
  getServer: async (id: number) => {
    try {
      // Obtener el servidor
      const serverResult = await db.select().from(servers).where(eq(servers.id, id));
      
      if (serverResult.length === 0) {
        return null;
      }
      
      const server = serverResult[0];
      
      // Obtener los jugadores del servidor
      const playersResult = await db.select().from(players).where(eq(players.serverId, id));
      
      // Combinar datos
      return {
        ...server,
        players: playersResult
      };
    } catch (error) {
      console.error("Error fetching server:", error);
      return null;
    }
  },
  
  // Favorites methods
  getFavorites: async (userId: string) => {
    try {
      // Obtener los IDs de los servidores favoritos del usuario
      const favoriteServers = await db
        .select()
        .from(favorites)
        .where(eq(favorites.userId, userId))
        .innerJoin(servers, eq(favorites.serverId, servers.id));
      
      return favoriteServers.map(row => row.servers);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      return [];
    }
  },
  
  isFavorite: async (userId: string, serverId: number) => {
    try {
      const result = await db
        .select()
        .from(favorites)
        .where(
          and(
            eq(favorites.userId, userId),
            eq(favorites.serverId, serverId)
          )
        );
      
      return result.length > 0;
    } catch (error) {
      console.error("Error checking favorite:", error);
      return false;
    }
  },
  
  addFavorite: async ({ userId, serverId }: { userId: string; serverId: number }) => {
    try {
      const result = await db.insert(favorites).values({
        userId,
        serverId
      }).returning();
      
      return result[0];
    } catch (error) {
      console.error("Error adding favorite:", error);
      throw error;
    }
  },
  
  removeFavorite: async (userId: string, serverId: number) => {
    try {
      await db
        .delete(favorites)
        .where(
          and(
            eq(favorites.userId, userId),
            eq(favorites.serverId, serverId)
          )
        );
      
      return true;
    } catch (error) {
      console.error("Error removing favorite:", error);
      return false;
    }
  },
  
  // Staff methods
  authenticateStaff: async (email: string, password: string) => {
    try {
      const hashedPassword = hashPassword(password);
      
      const result = await db
        .select()
        .from(staffAccounts)
        .where(
          and(
            eq(staffAccounts.email, email),
            eq(staffAccounts.password, hashedPassword)
          )
        );
      
      return result.length > 0 ? result[0] : null;
    } catch (error) {
      console.error("Error authenticating staff:", error);
      return null;
    }
  },
  
  addStaffMember: async (email: string, password: string, role: string) => {
    try {
      const hashedPassword = hashPassword(password);
      
      const result = await db.insert(staffAccounts).values({
        email,
        password: hashedPassword,
        role
      }).returning();
      
      return result[0];
    } catch (error) {
      console.error("Error adding staff member:", error);
      throw error;
    }
  },
  
  getStaffMembers: async () => {
    try {
      return await db.select().from(staffAccounts);
    } catch (error) {
      console.error("Error fetching staff members:", error);
      return [];
    }
  },
  
  // Chat methods
  createChannel: async (userId: string, userIp?: string) => {
    try {
      const result = await db.insert(chatChannels).values({
        userId,
        userIp,
        status: 'open'
      }).returning();
      
      return result[0];
    } catch (error) {
      console.error("Error creating chat channel:", error);
      throw error;
    }
  },
  
  getChatChannelByUserId: async (userId: string) => {
    try {
      const result = await db
        .select()
        .from(chatChannels)
        .where(eq(chatChannels.userId, userId))
        .orderBy(desc(chatChannels.createdAt))
        .limit(1);
      
      return result.length > 0 ? result[0] : null;
    } catch (error) {
      console.error("Error fetching chat channel by user ID:", error);
      return null;
    }
  },
  
  getChatChannelByIp: async (userIp: string) => {
    try {
      const result = await db
        .select()
        .from(chatChannels)
        .where(eq(chatChannels.userIp, userIp))
        .orderBy(desc(chatChannels.createdAt))
        .limit(1);
      
      return result.length > 0 ? result[0] : null;
    } catch (error) {
      console.error("Error fetching chat channel by IP:", error);
      return null;
    }
  },
  
  getChatChannelById: async (channelId: number) => {
    try {
      const result = await db
        .select()
        .from(chatChannels)
        .where(eq(chatChannels.id, channelId));
      
      return result.length > 0 ? result[0] : null;
    } catch (error) {
      console.error("Error fetching chat channel by ID:", error);
      return null;
    }
  },
  
  getChatMessages: async (channelId: number) => {
    try {
      return await db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.channelId, channelId))
        .orderBy(chatMessages.createdAt);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      return [];
    }
  },
  
  addChatMessage: async (message: { content: string, sender: string, channelId: number, staffId?: string }) => {
    try {
      // Los mensajes del usuario se marcan como no leídos por defecto
      // Los mensajes del staff se marcan como leídos por defecto
      const isRead = message.sender === 'staff';
      
      const result = await db.insert(chatMessages).values({
        content: message.content,
        sender: message.sender,
        channelId: message.channelId,
        isRead: isRead
        // No necesitamos guardar staffId por ahora
      }).returning();
      
      return result[0];
    } catch (error) {
      console.error("Error adding chat message:", error);
      throw error;
    }
  },
  
  getActiveChats: async () => {
    try {
      // Obtener todos los canales de chat activos (estados open y waiting)
      const channels = await db
        .select()
        .from(chatChannels)
        .where(
          or(
            eq(chatChannels.status, 'open'),
            eq(chatChannels.status, 'waiting')
          )
        )
        .orderBy(desc(chatChannels.createdAt));
      
      // Para cada canal, obtener el último mensaje
      const result = await Promise.all(
        channels.map(async (channel) => {
          const lastMessages = await db
            .select()
            .from(chatMessages)
            .where(eq(chatMessages.channelId, channel.id))
            .orderBy(desc(chatMessages.createdAt))
            .limit(1);
          
          // Contar los mensajes no leídos del usuario (no del staff)
          const unreadMessages = await db
            .select({ count: sql<number>`count(*)` })
            .from(chatMessages)
            .where(
              and(
                eq(chatMessages.channelId, channel.id),
                eq(chatMessages.sender, 'user'),
                eq(chatMessages.isRead, false)
              )
            );
          
          const lastMessage = lastMessages.length > 0 ? lastMessages[0] : null;
          const hasNewMessages = unreadMessages[0]?.count > 0;
          
          return {
            id: channel.id,
            userId: channel.userId,
            status: channel.status,
            lastMessage: lastMessage?.content || '',
            timestamp: channel.createdAt,
            hasNewMessages,
            unreadCount: unreadMessages[0]?.count || 0
          };
        })
      );
      
      return result;
    } catch (error) {
      console.error("Error fetching active chats:", error);
      return [];
    }
  },
  
  getStaffChats: async () => {
    try {
      // Obtener todos los canales de chat (tanto abiertos como cerrados)
      const channels = await db
        .select()
        .from(chatChannels)
        .orderBy(desc(chatChannels.createdAt));
      
      // Para cada canal, obtener el último mensaje
      const result = await Promise.all(
        channels.map(async (channel) => {
          const lastMessages = await db
            .select()
            .from(chatMessages)
            .where(eq(chatMessages.channelId, channel.id))
            .orderBy(desc(chatMessages.createdAt))
            .limit(1);
          
          // Contar todos los mensajes del canal
          const messageCount = await db
            .select({ count: sql<number>`count(*)` })
            .from(chatMessages)
            .where(eq(chatMessages.channelId, channel.id));
          
          // Contar los mensajes no leídos del usuario (no del staff)
          const unreadMessages = await db
            .select({ count: sql<number>`count(*)` })
            .from(chatMessages)
            .where(
              and(
                eq(chatMessages.channelId, channel.id),
                eq(chatMessages.sender, 'user'),
                eq(chatMessages.isRead, false)
              )
            );
          
          const lastMessage = lastMessages.length > 0 ? lastMessages[0] : null;
          const hasNewMessages = unreadMessages[0]?.count > 0;
          
          return {
            id: channel.id,
            userId: channel.userId,
            status: channel.status,
            lastMessage: lastMessage?.content || '',
            timestamp: channel.createdAt,
            messageCount: messageCount[0]?.count || 0,
            hasNewMessages,
            unreadCount: unreadMessages[0]?.count || 0
          };
        })
      );
      
      return result;
    } catch (error) {
      console.error("Error fetching staff chats:", error);
      return [];
    }
  },
  
  updateChatStatus: async (channelId: number, status: string) => {
    try {
      await db
        .update(chatChannels)
        .set({ status })
        .where(eq(chatChannels.id, channelId));
      
      // If the status is 'closed', delete all messages associated with this channel
      if (status === 'closed') {
        await db
          .delete(chatMessages)
          .where(eq(chatMessages.channelId, channelId));
      }
      
      return true;
    } catch (error) {
      console.error("Error updating chat status:", error);
      return false;
    }
  },
  
  markMessagesAsRead: async (channelId: number) => {
    try {
      // Marcar como leídos todos los mensajes del usuario en este canal
      await db
        .update(chatMessages)
        .set({ isRead: true })
        .where(
          and(
            eq(chatMessages.channelId, channelId),
            eq(chatMessages.sender, 'user'),
            eq(chatMessages.isRead, false)
          )
        );
      
      return true;
    } catch (error) {
      console.error("Error marking messages as read:", error);
      return false;
    }
  },
  
  // Email accounts methods
  addEmailAccount: async (account: { email: string, password: string }) => {
    try {
      const hashedPassword = hashPassword(account.password);
      
      const result = await db.insert(emailAccounts).values({
        email: account.email,
        password: hashedPassword
      }).returning();
      
      return result[0];
    } catch (error) {
      console.error("Error adding email account:", error);
      throw error;
    }
  },
  
  getEmailAccounts: async () => {
    try {
      return await db.select().from(emailAccounts);
    } catch (error) {
      console.error("Error fetching email accounts:", error);
      return [];
    }
  },
  
  deleteEmailAccount: async (id: number) => {
    try {
      await db
        .delete(emailAccounts)
        .where(eq(emailAccounts.id, id));
    } catch (error) {
      console.error("Error deleting email account:", error);
      throw error;
    }
  }
};