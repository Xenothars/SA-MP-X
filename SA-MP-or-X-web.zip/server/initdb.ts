import { db } from "./db";
import { servers, players, staffAccounts, emailAccounts } from "@shared/schema";
import * as crypto from "crypto";

// Función para hacer hash de contraseñas
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export async function initializeDatabase() {
  console.log("Initializing database...");
  
  try {
    // Comprobar si ya hay datos en la tabla de servidores
    const existingServers = await db.select().from(servers);
    
    if (existingServers.length === 0) {
      console.log("Populating servers table...");
      
      // Insertar datos de servidores
      await db.insert(servers).values([
        {
          name: "Roleplay Latino",
          ip: "51.81.49.97",
          port: 7777,
          gameMode: "Roleplay",
          language: "Español",
          passwordProtected: false,
          maxPlayers: 100,
          currentPlayers: 85,
          ping: 45,
          version: "0.3.7",
          description: "El mejor servidor de roleplay en español.",
          rules: "- No RDM/VDM\n- Respetar el rol\n- No insultar",
          isOnline: true
        },
        {
          name: "Carrera Extrema",
          ip: "45.32.68.193",
          port: 7777,
          gameMode: "Carreras",
          language: "Español",
          passwordProtected: false,
          maxPlayers: 50,
          currentPlayers: 25,
          ping: 60,
          version: "0.3.7",
          description: "El mejor servidor de carreras con pistas personalizadas.",
          rules: "- No chocar a propósito\n- No usar atajos no permitidos\n- No insultar",
          isOnline: true
        },
        {
          name: "Deathmatch Pro",
          ip: "145.239.5.189",
          port: 7777,
          gameMode: "Deathmatch",
          language: "English",
          passwordProtected: false,
          maxPlayers: 200,
          currentPlayers: 156,
          ping: 30,
          version: "0.3.7",
          description: "The best deathmatch server with custom weapons.",
          rules: "- Play fair\n- No cheating\n- Have fun",
          isOnline: true
        },
        {
          name: "RPG Zone",
          ip: "178.33.168.224",
          port: 7777,
          gameMode: "RPG",
          language: "English",
          passwordProtected: true,
          maxPlayers: 80,
          currentPlayers: 45,
          ping: 50,
          version: "0.3.7",
          description: "The most complete RPG server with jobs, houses and businesses.",
          rules: "- Respect the rules\n- No hack\n- No bug abuse",
          isOnline: true
        },
        {
          name: "Stunt Mania",
          ip: "51.254.69.111",
          port: 7777,
          gameMode: "Stunt",
          language: "English",
          passwordProtected: false,
          maxPlayers: 100,
          currentPlayers: 75,
          ping: 40,
          version: "0.3.7",
          description: "The best stunt server with custom maps.",
          rules: "- Be friendly\n- No insulting\n- Enjoy the stunts",
          isOnline: true
        }
      ]);
      
      console.log("Servers added successfully");
      
      // Obtener los IDs de los servidores recién creados
      const serversList = await db.select().from(servers);
      
      // Agregar jugadores a los servidores
      if (serversList.length > 0) {
        console.log("Populating players table...");
        
        const playersData = [];
        
        for (const server of serversList) {
          // Generar entre 5 y 15 jugadores por servidor
          const playerCount = Math.floor(Math.random() * 10) + 5;
          
          for (let i = 0; i < playerCount; i++) {
            playersData.push({
              serverId: server.id,
              name: `Player${i + 1}_S${server.id}`,
              level: Math.floor(Math.random() * 100) + 1,
              ping: Math.floor(Math.random() * 300) + 10
            });
          }
        }
        
        await db.insert(players).values(playersData);
        console.log("Players added successfully");
      }
    } else {
      console.log("Servers table already contains data, skipping population");
    }
    
    // Comprobar si ya hay datos en la tabla de cuentas de personal
    const existingStaff = await db.select().from(staffAccounts);
    
    if (existingStaff.length === 0) {
      console.log("Populating staff accounts table...");
      
      // Insertar cuenta de administrador predeterminada
      await db.insert(staffAccounts).values({
        email: "admin@admin.com",
        password: hashPassword("admin123"),
        role: "owner"
      });
      
      console.log("Staff account added successfully");
    } else {
      console.log("Staff accounts table already contains data, skipping population");
    }
    
    // Comprobar si ya hay datos en la tabla de cuentas de correo electrónico
    const existingEmailAccounts = await db.select().from(emailAccounts);
    
    if (existingEmailAccounts.length === 0) {
      console.log("Populating email accounts table...");
      
      // Insertar algunas cuentas de correo electrónico de ejemplo
      await db.insert(emailAccounts).values([
        {
          email: "user1@example.com",
          password: hashPassword("password123")
        },
        {
          email: "user2@example.com",
          password: hashPassword("password456")
        }
      ]);
      
      console.log("Email accounts added successfully");
    } else {
      console.log("Email accounts table already contains data, skipping population");
    }
    
    console.log("Database initialization completed successfully");
  } catch (error) {
    console.error("Error initializing database:", error);
    throw error;
  }
}