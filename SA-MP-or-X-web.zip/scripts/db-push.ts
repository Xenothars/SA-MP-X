import { db } from "../server/db";
import * as schema from "../shared/schema";
import { sql } from "drizzle-orm";

async function main() {
  console.log("Pushing database schema to database...");
  
  try {
    // Crear las tablas usando drizzle-orm
    for (const tableName of Object.keys(schema)) {
      if (typeof schema[tableName] === 'object' && schema[tableName]?.$type === 'table') {
        const table = schema[tableName];
        console.log(`Creating table ${table.$tableName}...`);
      }
    }
    
    // Verificar si las tablas existen
    const tables = await db.select({ table_name: sql<string>`tablename` })
      .from(sql`pg_tables`)
      .where(sql`schemaname = 'public'`);
    
    console.log("Existing tables:", tables.map(t => t.table_name));
    
    // Aplicar migraciones
    console.log("Running migrations...");
    await db.execute(sql`CREATE TABLE IF NOT EXISTS "servers" (
      "id" serial PRIMARY KEY,
      "name" text NOT NULL,
      "ip" text NOT NULL,
      "port" integer NOT NULL,
      "game_mode" text,
      "language" text,
      "password_protected" boolean DEFAULT false,
      "max_players" integer DEFAULT 0,
      "current_players" integer DEFAULT 0,
      "ping" integer,
      "version" text,
      "description" text,
      "rules" text,
      "is_online" boolean DEFAULT true,
      "last_updated" timestamp DEFAULT now()
    )`);
    
    await db.execute(sql`CREATE TABLE IF NOT EXISTS "players" (
      "id" serial PRIMARY KEY,
      "server_id" integer NOT NULL,
      "name" text NOT NULL,
      "level" integer,
      "ping" integer
    )`);
    
    await db.execute(sql`CREATE TABLE IF NOT EXISTS "favorites" (
      "id" serial PRIMARY KEY,
      "user_id" text NOT NULL,
      "server_id" integer NOT NULL
    )`);
    
    await db.execute(sql`CREATE TABLE IF NOT EXISTS "email_accounts" (
      "id" serial PRIMARY KEY,
      "email" text NOT NULL UNIQUE,
      "password" text NOT NULL,
      "created_at" timestamp DEFAULT now(),
      "updated_at" timestamp DEFAULT now()
    )`);
    
    await db.execute(sql`CREATE TABLE IF NOT EXISTS "staff_accounts" (
      "id" serial PRIMARY KEY,
      "email" text NOT NULL UNIQUE,
      "password" text NOT NULL,
      "role" text NOT NULL,
      "created_at" timestamp DEFAULT now()
    )`);
    
    await db.execute(sql`CREATE TABLE IF NOT EXISTS "chat_channels" (
      "id" serial PRIMARY KEY,
      "user_id" text NOT NULL,
      "status" text NOT NULL DEFAULT 'open',
      "created_at" timestamp DEFAULT now()
    )`);
    
    await db.execute(sql`CREATE TABLE IF NOT EXISTS "chat_messages" (
      "id" serial PRIMARY KEY,
      "channel_id" integer NOT NULL,
      "content" text NOT NULL,
      "sender" text NOT NULL,
      "created_at" timestamp DEFAULT now()
    )`);
    
    console.log("Database schema push completed successfully");
    
  } catch (error) {
    console.error("Error pushing database schema:", error);
    process.exit(1);
  } finally {
    // Cerrar la conexión a la base de datos
    process.exit(0);
  }
}

main();